// Local MPL-2.0 provider repair candidate. Legacy callers unchanged.
package sharedConstructors

import (
	"context"
	"encoding/json"
	"fmt"
	settingsjson "github.com/deploymenttheory/terraform-provider-microsoft365/internal/services/common/settingsjson"
	ser "github.com/microsoft/kiota-abstractions-go/serialization"
	jsonreader "github.com/microsoft/kiota-serialization-json-go"
	"sort"

	sharedmodels "github.com/deploymenttheory/terraform-provider-microsoft365/internal/services/common/shared_models/graph_beta/device_management"
	"github.com/hashicorp/terraform-plugin-framework/types"
	"github.com/hashicorp/terraform-plugin-log/tflog"
	graphmodels "github.com/microsoftgraph/msgraph-beta-sdk-go/models"
)

// ConstructSettingsCatalogSettings constructs a collection of settings catalog settings from a JSON string
// it supports simple, choice, simpleCollection, choiceCollection, and groupCollection settings and nested
// settings within choice and group collections recursively.
func ConstructSettingsCatalogSettings(ctx context.Context, settingsJSON types.String) []graphmodels.DeviceManagementConfigurationSettingable {
	tflog.Debug(ctx, "Constructing settings catalog settings")

	var configModel sharedmodels.DeviceConfigV2GraphServiceResourceModel

	if err := json.Unmarshal([]byte(settingsJSON.ValueString()), &configModel); err != nil {
		tflog.Error(ctx, "Failed to unmarshal settings JSON", map[string]any{
			"error": err.Error(),
		})
		return nil
	}

	tflog.Debug(ctx, "Unmarshaled settings catalog data from HCL", map[string]any{
		"data": configModel,
	})

	constructedSettings := make([]graphmodels.DeviceManagementConfigurationSettingable, 0)

	if len(configModel.Settings) > 0 {
		for _, setting := range configModel.Settings {
			processSetting(ctx, setting, &constructedSettings)
		}
	} else if configModel.Setting != nil {
		processSetting(ctx, *configModel.Setting, &constructedSettings)
	}

	tflog.Debug(ctx, "Constructed settings catalog settings", map[string]any{
		"count": len(constructedSettings),
	})

	return constructedSettings
}

// processSetting processes an individual settings catalog setting and appends it to the settingsRequestPayload.
//
// This function is part of the configuratioin policy / settings catalog 'json' resourceconstructor logic
// and is responsible for creating and configuring. It dynamically determines the type of setting
// based on the `@odata.type` field and handles different setting types, including:
// - Simple Settings
// - Choice Settings
// - Simple Collection Settings
// - Choice Collection Settings
// - Group Collection Settings
//
// Why Use a Separate Function for `processSetting`?
// -------------------------------------------------
// The Microsoft Graph API returns settings in a consistent format but allows for various nested and typed
// configurations. This function abstracts the logic of initializing, configuring, and appending each setting
// instance to the request payload, ensuring modularity and readability.
//
// Why Handle Both `settings` (Array) and `setting` (Single Instance)?
// -------------------------------------------------------------------
// The API always returns settings as an array, but it supports both single and multiple settings. As a result, the constructor
// allows for the definiton a single `setting` and `settings` array.
//
// Parameters:
//   - ctx: Context for logging and cancellation.
//   - setting: A `sharedmodels.Setting` object representing an individual setting to process.
//   - settingsRequestPayload: A pointer to a slice of `DeviceManagementConfigurationSettingable` where the processed
//     setting will be appended.
func processSetting(ctx context.Context, setting sharedmodels.Setting, settingsRequestPayload *[]graphmodels.DeviceManagementConfigurationSettingable) {
	baseSetting := graphmodels.NewDeviceManagementConfigurationSetting()
	instance, instanceType := createBaseInstance(ctx, setting.SettingInstance.ODataType, setting.SettingInstance.SettingDefinitionId)

	if instance == nil {
		return
	}

	switch instanceType {
	case "simple":
		simpleInstance := instance.(graphmodels.DeviceManagementConfigurationSimpleSettingInstanceable)
		if setting.SettingInstance.SimpleSettingValue != nil {
			simpleInstance.SetSimpleSettingValue(handleSimpleValue(ctx, setting.SettingInstance.SimpleSettingValue))
		}
		setInstanceTemplateReference(simpleInstance, setting.SettingInstance.SettingInstanceTemplateReference)
		baseSetting.SetSettingInstance(simpleInstance)

	case "choice":
		choiceInstance := instance.(graphmodels.DeviceManagementConfigurationChoiceSettingInstanceable)
		if setting.SettingInstance.ChoiceSettingValue != nil {
			choiceValue := graphmodels.NewDeviceManagementConfigurationChoiceSettingValue()
			choiceValue.SetValue(&setting.SettingInstance.ChoiceSettingValue.Value)
			setValueTemplateReference(choiceValue, setting.SettingInstance.ChoiceSettingValue.SettingValueTemplateReference)

			if len(setting.SettingInstance.ChoiceSettingValue.Children) > 0 {
				choiceChildren := handleChoiceSettingChildren(ctx, setting.SettingInstance.ChoiceSettingValue.Children)
				choiceValue.SetChildren(choiceChildren)
			}

			choiceInstance.SetChoiceSettingValue(choiceValue)
		}
		setInstanceTemplateReference(choiceInstance, setting.SettingInstance.SettingInstanceTemplateReference)
		baseSetting.SetSettingInstance(choiceInstance)

	case "simpleCollection":
		collectionInstance := instance.(graphmodels.DeviceManagementConfigurationSimpleSettingCollectionInstanceable)
		if len(setting.SettingInstance.SimpleSettingCollectionValue) > 0 {
			values := handleSimpleSettingCollection(setting.SettingInstance.SimpleSettingCollectionValue)
			collectionInstance.SetSimpleSettingCollectionValue(values)
		}
		setInstanceTemplateReference(collectionInstance, setting.SettingInstance.SettingInstanceTemplateReference)
		baseSetting.SetSettingInstance(collectionInstance)

	case "choiceCollection":
		collectionInstance := instance.(graphmodels.DeviceManagementConfigurationChoiceSettingCollectionInstanceable)
		if len(setting.SettingInstance.ChoiceSettingCollectionValue) > 0 {
			values := handleChoiceCollectionValue(ctx, setting.SettingInstance.ChoiceSettingCollectionValue)
			collectionInstance.SetChoiceSettingCollectionValue(values)
		}
		setInstanceTemplateReference(collectionInstance, setting.SettingInstance.SettingInstanceTemplateReference)
		baseSetting.SetSettingInstance(collectionInstance)

	case "groupCollection":
		groupInstance := instance.(graphmodels.DeviceManagementConfigurationGroupSettingCollectionInstanceable)
		if len(setting.SettingInstance.GroupSettingCollectionValue) > 0 {
			values := handleGroupSettingCollection(ctx, setting.SettingInstance.GroupSettingCollectionValue)
			groupInstance.SetGroupSettingCollectionValue(values)
		}
		setInstanceTemplateReference(groupInstance, setting.SettingInstance.SettingInstanceTemplateReference)
		baseSetting.SetSettingInstance(groupInstance)
	}

	*settingsRequestPayload = append(*settingsRequestPayload, baseSetting)
}

// createBaseInstance creates and initializes a new setting instance based on the provided OData type and setting definition ID.
// The function dynamically determines the appropriate type of the instance to create and returns it along with its type as a string.
// Supported types include:
// - Simple Setting Instance
// - Choice Setting Instance
// - Simple Setting Collection Instance
// - Choice Setting Collection Instance
// - Group Setting Collection Instance
//
// Parameters:
// - odataType: The OData type of the setting instance (e.g., "#microsoft.graph.deviceManagementConfigurationSimpleSettingInstance").
// - settingDefinitionId: The ID of the setting definition associated with this instance.
//
// Returns:
// - any: The newly created setting instance, or nil if the OData type is unsupported.
// - string: A string identifier for the type of the instance (e.g., "simple", "choice").
func createBaseInstance(ctx context.Context, odataType string, settingDefinitionId string) (any, string) {
	if odataType == "" {
		tflog.Error(ctx, "Invalid input: OData type is empty", map[string]any{
			"odataType": odataType,
		})
		return nil, ""
	}

	switch odataType {
	case "#microsoft.graph.deviceManagementConfigurationSimpleSettingInstance":
		instance := graphmodels.NewDeviceManagementConfigurationSimpleSettingInstance()
		instance.SetOdataType(&odataType)
		instance.SetSettingDefinitionId(&settingDefinitionId)
		return instance, "simple"

	case "#microsoft.graph.deviceManagementConfigurationChoiceSettingInstance":
		instance := graphmodels.NewDeviceManagementConfigurationChoiceSettingInstance()
		instance.SetOdataType(&odataType)
		instance.SetSettingDefinitionId(&settingDefinitionId)
		return instance, "choice"

	case "#microsoft.graph.deviceManagementConfigurationSimpleSettingCollectionInstance":
		instance := graphmodels.NewDeviceManagementConfigurationSimpleSettingCollectionInstance()
		instance.SetOdataType(&odataType)
		instance.SetSettingDefinitionId(&settingDefinitionId)
		return instance, "simpleCollection"

	case "#microsoft.graph.deviceManagementConfigurationChoiceSettingCollectionInstance":
		instance := graphmodels.NewDeviceManagementConfigurationChoiceSettingCollectionInstance()
		instance.SetOdataType(&odataType)
		instance.SetSettingDefinitionId(&settingDefinitionId)
		return instance, "choiceCollection"

	case "#microsoft.graph.deviceManagementConfigurationGroupSettingCollectionInstance":
		instance := graphmodels.NewDeviceManagementConfigurationGroupSettingCollectionInstance()
		instance.SetOdataType(&odataType)
		instance.SetSettingDefinitionId(&settingDefinitionId)
		return instance, "groupCollection"
	}

	return nil, ""
}

// handleSimpleValue processes a simple setting value and returns the corresponding model instance.
// It supports various types of simple settings such as string, integer, and secret values, and dynamically
// creates the appropriate setting value instance based on the OData type.
//
// Parameters:
// - ctx: The context for logging and other operations.
// - valueStruct: A pointer to the SimpleSettingStruct containing the value to process and its associated metadata.
//
// Supported OData types:
// - "#microsoft.graph.deviceManagementConfigurationStringSettingValue" (string values)
// - "#microsoft.graph.deviceManagementConfigurationIntegerSettingValue" (integer values)
// - "#microsoft.graph.deviceManagementConfigurationSecretSettingValue" (secret values with value state)
//
// Returns:
//   - graphmodels.DeviceManagementConfigurationSimpleSettingValueable: The processed setting value instance,
//     or nil if the OData type is unsupported or an error occurs.
//
// Logs:
//   - Logs an error if the function is unable to process the provided valueStruct due to an unsupported type
//     or invalid value.
func handleSimpleValue(ctx context.Context, valueStruct *sharedmodels.SimpleSettingStruct) graphmodels.DeviceManagementConfigurationSimpleSettingValueable {
	if valueStruct == nil {
		return nil
	}

	var result graphmodels.DeviceManagementConfigurationSimpleSettingValueable

	switch valueStruct.ODataType {
	case "#microsoft.graph.deviceManagementConfigurationStringSettingValue":
		if strValue, ok := valueStruct.Value.(string); ok {
			stringValue := graphmodels.NewDeviceManagementConfigurationStringSettingValue()
			stringValue.SetOdataType(&valueStruct.ODataType)
			stringValue.SetValue(&strValue)
			result = stringValue
		}

	case "#microsoft.graph.deviceManagementConfigurationIntegerSettingValue":
		if numValue, ok := valueStruct.Value.(float64); ok {
			intValue := graphmodels.NewDeviceManagementConfigurationIntegerSettingValue()
			intValue.SetOdataType(&valueStruct.ODataType)
			int32Value := int32(numValue)
			intValue.SetValue(&int32Value)
			result = intValue
		}

	case "#microsoft.graph.deviceManagementConfigurationSecretSettingValue":
		if strValue, ok := valueStruct.Value.(string); ok {
			secretValue := graphmodels.NewDeviceManagementConfigurationSecretSettingValue()
			secretValue.SetOdataType(&valueStruct.ODataType)
			secretValue.SetValue(&strValue)
			if valueStruct.ValueState != "" {
				if state, err := graphmodels.ParseDeviceManagementConfigurationSecretSettingValueState(valueStruct.ValueState); err == nil {
					secretValue.SetValueState(state.(*graphmodels.DeviceManagementConfigurationSecretSettingValueState))
				}
			}
			result = secretValue
		}
	}

	if result != nil {
		setValueTemplateReference(result, valueStruct.SettingValueTemplateReference)
		return result
	}

	tflog.Error(ctx, "Failed to handle simple setting value", map[string]any{
		"type":  valueStruct.ODataType,
		"value": valueStruct.Value,
	})
	return nil
}

// handleSimpleSettingCollection is a helper function to handle simple setting collections
func handleSimpleSettingCollection(collectionValues []sharedmodels.SimpleSettingCollectionStruct) []graphmodels.DeviceManagementConfigurationSimpleSettingValueable {
	var values []graphmodels.DeviceManagementConfigurationSimpleSettingValueable
	for _, v := range collectionValues {
		stringValue := graphmodels.NewDeviceManagementConfigurationStringSettingValue()
		stringValue.SetOdataType(&v.ODataType)
		stringValue.SetValue(&v.Value)
		setValueTemplateReference(stringValue, v.SettingValueTemplateReference)
		values = append(values, stringValue)
	}
	return values
}

// handleChoiceSettingChildren recursively processes a list of choice setting children.
// Each child is converted into a setting instance based on its OData type and configuration,
// supporting nested recursive structures.
//
// Parameters:
// - ctx: The context for logging and operations.
// - children: A slice of sharedmodels.ChoiceSettingChild representing the choice setting children to process.
//
// Returns:
// - []graphmodels.DeviceManagementConfigurationSettingInstanceable: A slice of processed setting instances.
func handleChoiceSettingChildren(ctx context.Context, children []sharedmodels.ChoiceSettingChild) []graphmodels.DeviceManagementConfigurationSettingInstanceable {
	var result []graphmodels.DeviceManagementConfigurationSettingInstanceable

	for _, child := range children {
		instance := handleSettingInstance(ctx, sharedmodels.SettingInstance{
			ODataType:                        child.ODataType,
			SettingDefinitionId:              child.SettingDefinitionId,
			SettingInstanceTemplateReference: child.SettingInstanceTemplateReference,
			SimpleSettingValue:               child.SimpleSettingValue,
			SimpleSettingCollectionValue:     child.SimpleSettingCollectionValue,
			ChoiceSettingValue:               child.ChoiceSettingValue,
			ChoiceSettingCollectionValue:     child.ChoiceSettingCollectionValue,
			GroupSettingCollectionValue:      child.GroupSettingCollectionValue,
		})
		if instance != nil {
			result = append(result, instance)
		}
	}

	return result
}

// handleGroupSettingCollection recursively processes a list of group setting collections.
// Each group item and its children are converted into setting instances based on their OData type
// and configuration, supporting deeply nested group structures.
//
// Parameters:
// - ctx: The context for logging and operations.
// - groupValues: A slice of sharedmodels.GroupSettingCollectionStruct representing the group setting collections to process.
//
// Returns:
// - []graphmodels.DeviceManagementConfigurationGroupSettingValueable: A slice of processed group setting values.
func handleGroupSettingCollection(ctx context.Context, groupValues []sharedmodels.GroupSettingCollectionStruct) []graphmodels.DeviceManagementConfigurationGroupSettingValueable {
	var values []graphmodels.DeviceManagementConfigurationGroupSettingValueable

	for _, groupItem := range groupValues {
		groupValue := graphmodels.NewDeviceManagementConfigurationGroupSettingValue()
		var children []graphmodels.DeviceManagementConfigurationSettingInstanceable

		for _, child := range groupItem.Children {
			instance := handleSettingInstance(ctx, sharedmodels.SettingInstance{
				ODataType:                        child.ODataType,
				SettingDefinitionId:              child.SettingDefinitionId,
				SettingInstanceTemplateReference: child.SettingInstanceTemplateReference,
				SimpleSettingValue:               child.SimpleSettingValue,
				SimpleSettingCollectionValue:     child.SimpleSettingCollectionValue,
				ChoiceSettingValue:               child.ChoiceSettingValue,
				ChoiceSettingCollectionValue:     child.ChoiceSettingCollectionValue,
				GroupSettingCollectionValue:      child.GroupSettingCollectionValue,
			})
			if instance != nil {
				children = append(children, instance)
			}
		}

		groupValue.SetChildren(children)
		setValueTemplateReference(groupValue, groupItem.SettingValueTemplateReference)
		values = append(values, groupValue)
	}

	return values
}

// Helper function to handle choice collection values recursively
func handleChoiceCollectionValue(ctx context.Context, collectionValues []sharedmodels.ChoiceSettingCollectionStruct) []graphmodels.DeviceManagementConfigurationChoiceSettingValueable {
	var values []graphmodels.DeviceManagementConfigurationChoiceSettingValueable

	for _, choiceItem := range collectionValues {
		choiceValue := graphmodels.NewDeviceManagementConfigurationChoiceSettingValue()
		choiceValue.SetValue(&choiceItem.Value)
		setValueTemplateReference(choiceValue, choiceItem.SettingValueTemplateReference)

		var children []graphmodels.DeviceManagementConfigurationSettingInstanceable
		for _, child := range choiceItem.Children {
			instance, instanceType := createBaseInstance(ctx, child.ODataType, child.SettingDefinitionId)
			if instance == nil {
				continue
			}

			switch instanceType {
			case "simple":
				simpleInstance := instance.(graphmodels.DeviceManagementConfigurationSimpleSettingInstanceable)
				if child.SimpleSettingValue != nil {
					simpleInstance.SetSimpleSettingValue(handleSimpleValue(ctx, child.SimpleSettingValue))
				}
				setInstanceTemplateReference(simpleInstance, child.SettingInstanceTemplateReference)
				children = append(children, simpleInstance)

			case "simpleCollection":
				collectionInstance := instance.(graphmodels.DeviceManagementConfigurationSimpleSettingCollectionInstanceable)
				if len(child.SimpleSettingCollectionValue) > 0 {
					simpleValues := handleSimpleSettingCollection(child.SimpleSettingCollectionValue)
					collectionInstance.SetSimpleSettingCollectionValue(simpleValues)
				}
				setInstanceTemplateReference(collectionInstance, child.SettingInstanceTemplateReference)
				children = append(children, collectionInstance)
			}
		}

		choiceValue.SetChildren(children)
		values = append(values, choiceValue)
	}

	return values
}

// handleSettingInstance processes a given setting instance by creating and configuring
// the appropriate type based on its OData type and setting definition ID. This function
// supports recursive handling of nested settings, including simple, choice, collection,
// and group settings.
//
// Parameters:
// - ctx: The context for logging and operations.
// - instance: A sharedmodels.SettingInstance object representing the setting to process.
//
// Returns:
// - graphmodels.DeviceManagementConfigurationSettingInstanceable: The configured setting instance, or nil if the input is invalid or unsupported.
func handleSettingInstance(ctx context.Context, instance sharedmodels.SettingInstance) graphmodels.DeviceManagementConfigurationSettingInstanceable {
	baseInstance, instanceType := createBaseInstance(ctx, instance.ODataType, instance.SettingDefinitionId)
	if baseInstance == nil {
		return nil
	}

	switch instanceType {
	case "simple":
		simpleInstance := baseInstance.(graphmodels.DeviceManagementConfigurationSimpleSettingInstanceable)
		if instance.SimpleSettingValue != nil {
			simpleInstance.SetSimpleSettingValue(handleSimpleValue(ctx, instance.SimpleSettingValue))
		}
		setInstanceTemplateReference(simpleInstance, instance.SettingInstanceTemplateReference)
		return simpleInstance

	case "choice":
		choiceInstance := baseInstance.(graphmodels.DeviceManagementConfigurationChoiceSettingInstanceable)
		if instance.ChoiceSettingValue != nil {
			choiceValue := graphmodels.NewDeviceManagementConfigurationChoiceSettingValue()
			choiceValue.SetValue(&instance.ChoiceSettingValue.Value)
			setValueTemplateReference(choiceValue, instance.ChoiceSettingValue.SettingValueTemplateReference)

			if len(instance.ChoiceSettingValue.Children) > 0 {
				children := handleChoiceSettingChildren(ctx, instance.ChoiceSettingValue.Children)
				choiceValue.SetChildren(children)
			}
			choiceInstance.SetChoiceSettingValue(choiceValue)
		}
		setInstanceTemplateReference(choiceInstance, instance.SettingInstanceTemplateReference)
		return choiceInstance

	case "simpleCollection":
		collectionInstance := baseInstance.(graphmodels.DeviceManagementConfigurationSimpleSettingCollectionInstanceable)
		if len(instance.SimpleSettingCollectionValue) > 0 {
			values := handleSimpleSettingCollection(instance.SimpleSettingCollectionValue)
			collectionInstance.SetSimpleSettingCollectionValue(values)
		}
		setInstanceTemplateReference(collectionInstance, instance.SettingInstanceTemplateReference)
		return collectionInstance

	case "choiceCollection":
		collectionInstance := baseInstance.(graphmodels.DeviceManagementConfigurationChoiceSettingCollectionInstanceable)
		if len(instance.ChoiceSettingCollectionValue) > 0 {
			values := handleChoiceCollectionValue(ctx, instance.ChoiceSettingCollectionValue)
			collectionInstance.SetChoiceSettingCollectionValue(values)
		}
		setInstanceTemplateReference(collectionInstance, instance.SettingInstanceTemplateReference)
		return collectionInstance

	case "groupCollection":
		groupInstance := baseInstance.(graphmodels.DeviceManagementConfigurationGroupSettingCollectionInstanceable)
		if len(instance.GroupSettingCollectionValue) > 0 {
			values := handleGroupSettingCollection(ctx, instance.GroupSettingCollectionValue)
			groupInstance.SetGroupSettingCollectionValue(values)
		}
		setInstanceTemplateReference(groupInstance, instance.SettingInstanceTemplateReference)
		return groupInstance
	}

	return nil
}

// setInstanceTemplateReference creates and assigns a SettingInstanceTemplateReference to a setting instance.
// This function adds the template reference metadata to a given setting instance if the reference is provided.
//
// Parameters:
// - instance: The setting instance implementing DeviceManagementConfigurationSettingInstanceable.
// - ref: The SettingInstanceTemplateReference containing the template ID.
//
// Example:
// Input:
//
//	{
//	    "settingInstanceTemplateReference": {
//	        "settingInstanceTemplateId": "template-id-123"
//	    }
//	}
func setInstanceTemplateReference(instance graphmodels.DeviceManagementConfigurationSettingInstanceable, ref *sharedmodels.SettingInstanceTemplateReference) {
	if ref != nil {
		templateRef := graphmodels.NewDeviceManagementConfigurationSettingInstanceTemplateReference()
		templateRef.SetSettingInstanceTemplateId(&ref.SettingInstanceTemplateId)
		instance.SetSettingInstanceTemplateReference(templateRef)
	}
}

// setValueTemplateReference creates and assigns a SettingValueTemplateReference to a value object.
// This function adds the template reference metadata to a value object if the reference is provided.
// It supports group, choice, and simple setting value types.
//
// Parameters:
// - value: The value object implementing one of the supported interfaces (Group, Choice, or Simple setting values).
// - ref: The SettingValueTemplateReference containing the template ID and `useTemplateDefault` flag.
//
// Example:
// Input:
//
//	{
//	    "value": "example-value",
//	    "settingValueTemplateReference": {
//	        "settingValueTemplateId": "template-id-456",
//	        "useTemplateDefault": true
//	    }
//	}
//
// Effect:
// The `value` will have its SettingValueTemplateReference field set to:
//
//	{
//	    "settingValueTemplateId": "template-id-456",
//	    "useTemplateDefault": true
//	}
//
// Supported Value Types:
// - GroupSettingValue
// - ChoiceSettingValue
// - SimpleSettingValue
func setValueTemplateReference(value any, ref *sharedmodels.SettingValueTemplateReference) {
	if ref != nil {
		templateRef := graphmodels.NewDeviceManagementConfigurationSettingValueTemplateReference()
		templateRef.SetSettingValueTemplateId(&ref.SettingValueTemplateId)
		templateRef.SetUseTemplateDefault(&ref.UseTemplateDefault)

		switch v := value.(type) {
		case graphmodels.DeviceManagementConfigurationGroupSettingValueable:
			v.SetSettingValueTemplateReference(templateRef)
		case graphmodels.DeviceManagementConfigurationChoiceSettingValueable:
			v.SetSettingValueTemplateReference(templateRef)
		case graphmodels.DeviceManagementConfigurationSimpleSettingValueable:
			v.SetSettingValueTemplateReference(templateRef)
		}
	}
}

// The generated SDK omits nulls and adds default discriminators. Retain the
// validated input JSON for serialization while populating actual SDK getters.
// This deliberately preserves every input field and array position.
type exactSetting struct {
	*graphmodels.DeviceManagementConfigurationSetting
	raw map[string]any
}

func (s *exactSetting) Serialize(writer ser.SerializationWriter) error {
	keys := make([]string, 0, len(s.raw))
	for k := range s.raw {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, key := range keys {
		var err error
		if s.raw[key] == nil {
			err = writer.WriteNullValue(key)
		} else {
			err = writer.WriteAnyValue(key, s.raw[key])
		}
		if err != nil {
			return fmt.Errorf("setting serialization failed")
		}
	}
	return nil
}
func ConstructSettingsCatalogSettingsStrict(ctx context.Context, settings types.String) ([]graphmodels.DeviceManagementConfigurationSettingable, error) {
	if settings.IsNull() || settings.IsUnknown() {
		return nil, fmt.Errorf("settings must be known before mutation")
	}
	rows, err := settingsjson.Settings([]byte(settings.ValueString()), false)
	if err != nil {
		return nil, err
	}
	result := make([]graphmodels.DeviceManagementConfigurationSettingable, 0, len(rows))
	for _, row := range rows {
		data, err := json.Marshal(row)
		if err != nil {
			return nil, fmt.Errorf("setting encoding failed")
		}
		node, err := jsonreader.NewJsonParseNode(data)
		if err != nil {
			return nil, fmt.Errorf("setting SDK parse failed")
		}
		value, err := node.GetObjectValue(graphmodels.CreateDeviceManagementConfigurationSettingFromDiscriminatorValue)
		if err != nil {
			return nil, fmt.Errorf("setting SDK conversion failed")
		}
		setting, ok := value.(*graphmodels.DeviceManagementConfigurationSetting)
		if !ok {
			return nil, fmt.Errorf("unexpected SDK setting model")
		}
		id := row["id"].(string)
		setting.SetId(&id)
		result = append(result, &exactSetting{DeviceManagementConfigurationSetting: setting, raw: row})
	}
	return result, nil
}
