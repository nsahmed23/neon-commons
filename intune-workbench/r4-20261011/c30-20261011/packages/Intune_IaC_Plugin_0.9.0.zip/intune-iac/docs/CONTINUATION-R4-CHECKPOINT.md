# C30 current checkpoint — 2026-10-11

The dedicated known-completed restart readback path is now integrated. `intune_iac.worker_completed_readback.collect(*, job_root, policy_path, observation, output)` accepts a fresh exact sealed observation from `observe(require_locked=False)`, validates the original completed operation and current observer inventory, and reopens the actual service authority. `ServiceJob.reconcile` retains the known original status/outcome digest until independent readback permits scope discharge. It never manufactures an exceptional committed-state release or replays the original write. Retain `capture = sealed.captured_observation()` before reconciliation, then publish that retained capture; after convergence the capability deliberately rejects reuse.

The observing source is an exact **uncommitted C30 working tree on C29 parent `571e06ba015a9b94208e4c88538246c97e3816e4`**. Current commit/tree/packages are pending root freeze and review. Core bytes are `worker_service.py`58,296/SHA40f6caf0…, new `worker_completed_readback.py`14,304/edfe6e78…, and new test25,298/41658847…. The precise source/runbook/inventory identities appear in [the applied independent admission](continuation-evidence/20261011/checkpoint30/core/applied-admission.json). The root-managed runbook is15,745bytes/SHA2068c4cb…; inventory preserves all3,443previous paths/comments and adds2core paths, before any selected C30metadata additions. No code/runbook/inventory is overwritten by this documentation proposal.

[Changed-scope evidence](continuation-evidence/20261011/checkpoint30/core/changed-scope-result.json) records **123 unique planned/executed local methods across nine affected worker families, with zero failures, errors, skips, expected failures or unexpected successes**, source before/after pins unchanged. New19 methods are included, not added to123. Independent original30API/SQL controls and185source checks, author19 and the139applied reader guards overlap; there is no union count. Historical host and recorded observation dependencies are modeled, with zero real native/provider/organizational receiving-service dispatches. The actual factory/reopened service authority and negative controls do run. This is local changed-interface PASS, not whole laboratory or final package qualification.

Preserve failed proposed observer01 (`f46f44f9…`): version01 omitted the current observer inventory check; exact02 rejects that substitution without releasing reservations. The independent AST checker initially mistook ordinary SQLite `db.execute(SELECT)` for exceptional release and was corrected without changing candidate bytes. Author discovery initially included12imported historical repeats; own19 stays separate. Full private proposals/reports remain retained; their source/public metadata admissions do not authorize publishing raw state, SQL, captures, profiles, keys or approvals.

The [ordinary timing source03 admission](continuation-evidence/20261011/checkpoint30/ordinary-timing/source-admission.json) and [timing4 profile admission](continuation-evidence/20261011/checkpoint30/ordinary-timing/profile-admission.json) now finish those scoped preparation contracts. Four actual native cases remain NOT_STARTED: acquisition cancellation, policy-response cancellation, archive recording failure and compound recording failure. The first two expect `outcome_unknown`/state13. The last two preserve `host_completed_service_unverified`/state14 with a normally released lease; a late archive/recording failure must not be converted into a held-lease unknown operation. A compound failure may leave no new persisted error record: preserve existing failure evidence and known committed provenance rather than assert a fabricated SQL event.

The exact public helper/control texts and loader/outer/README are selected outside runtime. Source85pure cases/30linkage/170source checks and profile263metadata/55negative controls overlap and are not product/native totals. The old parsed-URI hypothesis was disproved because the real frozen journal retains fullURI `?comp=lease`; retain that reviewer history. A deliberately malformed pure-selector gap was repaired03, and old ZIP-prefix/substring/count checker failures are preserved. These preparations bind C25engine/helper/tool/seed bytes. The changed C30engine requires a new explicit final-source binding; a frozen C25profile is not silently usable with it.

C29 source `571e06…` (tree1eff08bf…) was actually committed/pushed and all50selected paths anonymously read back. Companion `b7c6515ac3e99f6a548d774805a905df0c44baf1` (tree643b49d2…) has129exact anonymousHTTP200matches/24,589,195bytes including unchanged C25source/runtime ZIPs. [Its independent delivery disposition](continuation-evidence/20261011/checkpoint30/delivery/checkpoint29-companion-delivery.json) keeps the original push **FAIL** after remote write: inherited singleR3fetch projection prevented local R4upstream assignment. Separate beforeexit128/after0 tracking repair preserved R3 and added only four config lines, without repeating push/fetch. A verified readback does not rewrite the failed attempt. Neon/defaultmain remained `4ba077d93fecbf5f893ee13ef972c839cf13883d`.

Exact C25source `e3bdefe0b1ac0c58e46f9af3360970f8e47ae393`, sourceZIPb18dd90c…(17,956,520bytes) and runtime7ca39bc4…(1,520,542bytes) remain historical qualified artifacts. Source2307strict, bounded performance and modeled-runtime64checks/34commands/10LinuxPTY scopes remain preserved; **they do not qualify the changed C30engine**. Previous gate01FAIL/target9PASS/gate02PASS and separate1141/1242baselines are not summed or broadly rerun. New exact commit/tree/inventory/packages and required changed-source source/runtime/application gates are the next independent local dependency.

Native receiving space still fails the unchanged32MiB+64KiB reserve. The last preparation receipt reports22,941,696bytes available; remeasure at admission. Root requested an existing authorized private persistent filesystem with at least256MiBfree. Generic Driveupload/Pagefilereference tool metadata supplies neither a selected approved destination nor native receiving capacity; no connector write or identity lookup occurred. Do not prune archives/history, weaken reserve, activate credentials, deploy services or presume authority from connector presence. Once suitable space exists, root restages exact dependencies and receiving configuration, obtains fresh applicable approval/current held-state readback and explicit GO, then executes once only. Never replay consumed original apply/release.

Original native run01 remains FAIL:38planned/6attempted/5completed/32notattempted, with the sixth policyPUT204/assignment403/state13 unchanged and an unknown outcome/held lease/two reservations. Admitted normal32 and additional32 contracts have no new native outcomes. Final-source timing/recovery/no-change/readback/reopened history and independent raw capsules remain required. New selected private preparation preservation does not restore265historical temporary roots/39receipt references or close original unexpected files, actor/helper attribution, provider denial or Wally87completed/nine timeouts/no demonstrated benefit.

**Laboratory: IMPLEMENTED, incomplete. Platform: BLOCKED. Organizational production approval: BLOCKED.** Required real nativeWindows/GitBash/mintty/PowerShell, organizational CI choice/protected runs, authenticGraph/Azure/backend identities, enrolled devices, independently installed OSscheduler, crash/containment/keycustody/AppSec and accountable risk/production approval remain distinct gates with their original owners/procedures. G13automaticapproval denial remains; no alternate bypass.

Resume without replaying operations:

```sh
cd /workspace/intune-continuation/work/projects/intune
git status --short
git log -5 --oneline
cat docs/EXECUTION-SEQUENCE-R4.md
cat docs/continuation-evidence/20261011/checkpoint30/core/applied-admission.json
```

The completed123procedure's exact runner is retained privately at `work/evidence/epoch-20261007-r4/integration/known-completion-C30-application-20261011-01/verify-changed-scope.py` (3,227bytes/SHA716e8e1d…), with raw logc0b709c1… and metadataf224b903…. Its original output directory is immutable; a justified replay must use a newly reviewed literal output path. No replay is currently required. Next: independently admit/commit/publish this exact source increment, build new exact packages and qualify their required gates, while the storage owner resolves native receiving space. Final packages and final-source native qualification will have subsequent durable checkpoints.

---

## Historical C29 document — retained byte-exact

C29 preparation checkpoint — 2026-10-11

This is the current preparation increment. The complete previous C28 document below remains byte-exact historical prose; reuse only evidence whose exact dependencies remain applicable. Current documentation base is `94bfbcc2de93f498ecaedb43b2a9fea5e36b9db4` (tree `9ceaa3d87f7ce68d72c215c73d79b8cf9bd0be4f`). Current C29 commit/publication is pending root application and verified readback. Tested engine/runtime basis remains C25 `e3bdefe0b1ac0c58e46f9af3360970f8e47ae393`; exact source ZIP SHA `b18dd90c742e8082fef635c08807985ba631eb7634a2e4386c307daa3527917e` (17,956,520 bytes), runtime SHA `7ca39bc46cef9d8a699ea1885646fcecd281cd7e6677607b106267eb6a8fd84d` (1,520,542 bytes). No engine/package rebuild or source-suite/performance/native rerun occurred in this documentation lane.

Two external receipt producer fields now convert ordered SQL tuples to JSON arrays. Internal tuple checks and strict canonical linkage remain unchanged. Independent first-site21controls and second-site source/AST/dependency reuse pass only that scoped contract. Original native run01 stays FAIL:38 planned actions,6 attempted,5 completed,32 not attempted. The sixth fault left policyPUT204/assignment403/state serial13 unchanged, outcome_unknown, a held lease and two reservations. Scenario/cleanup PASS does not recover or reclassify it. Historical approval is expired; metadata-only witness57assertions/6public-keycrypto commands/10reader controls is not a fresh authorization. Never replay the consumed apply/release.

New loader04 `61053f920d569d5091bd64c0f7a7219d7119a7064fa0adb1c42ad6abb36f8fd3` (60,974 bytes), profile04 `fb35b21001e4e25073bbe6cffb66db037cc62105a0a0e4fbb116ff0736993d8c`, outer05 `70fd24ad0340bdc0a1f8788786770677d2109980f6233058acbb4c115a37c90b` (63,040 bytes), configuration `c0974c00fc8bd70b62d890c324a4315015ef64ce4e6792ab52b8c2667c3c59e4`, reuse `86722a4dddace883d655d5fae0eec79f895a13e9e9fd350e3d6647911a9f0f3b`, fixed32-action plan `5cf87344cd472528a8b82d98ef33502c7e9ffb87dde39f268c3fc20a1718db76` are reviewed preparation. Final admission59cd0d80 covers exact read-only/metadata and selected source-text scopes, not native GO. NC01/NC02 before7faf/after3082 and NC03 failed3082/repaired6105 controls remain separate. Validfalse passes; integer0/float0.0 substitutions reject. Twenty profile negatives, six outer controls, twelve admission metadata controls and snapshot-before/after evidence overlap; no summed product/native count.

Reviewed source is navigable in `continuation-evidence/20261011/checkpoint29/normal32/` and `producer-repair/`. Public text is not a standalone runnable private profile or production worker authorization. The exact producer repair MD preserves its preparation-time pending-review footer; current96d2/59cd admission supplies its actual selected-source scope. Full helper bodies, private creators/profile/reuse/witness/rawstate/plans/keys/approvals/GO/capsules remain omitted explicitly.

Selected private preparation preservation passed:322,348-byte capsule SHA `d8b82641aebd4311074d75b0f6a53060a554f2c99fa07969577040c9a5a8a660`,22 declared roots/446typed nodes,154archive members/153unique payload blobs, no links followed and exact receiving readback. Its private receipt ba2b07cb and capsule are not public candidates. This is selected new preparation preservation, not full corpus or IPC/native recovery. The265missing historical temporary roots/39unavailable references, originalhelper/actor/provenance findings, failed candidates and denied G13 provider lane remain unresolved.

The extra abnormal-mode preparation has8fresh cases/20seed-release actions+12no-change/history actions, total32additional actions. It is distinct from the reviewed remaining normal32 and has no executed native outcome. Author checks remain distinct; final extra03 independent325metadata/100negative source preparation nowpassesits precise contract, with all32actualnativeoutcomesNOT_STARTED. Three ordinary native timing-stage helpers are under exact status/query/recovery-closure revision; actual outcomes remain NOT_STARTED. The initial reviewer parsed-URI hypothesis was DISPROVED because real frozen fixture journals retain fullURI including `?comp=lease`; preserve finding and correction as reviewer history, not native/product failing-before evidence.

C28 source publication8462f1, anonymous17-path readback3ad2c451 and independent51-assertion actual Gitblob binding6c089914 are complete in their exact documentation scope. C28 inert79-file companion selection b2802d75 is independently admitted a3c3f052 with prior-interface c7d09b69, but has not been published. Reader0b8ea independently corrects the C28 whole-public-delta contract while preserving C27 complete-RESULT semantics and originalf3a failure;2readonlyvalidate positives/22negatives/48Gitpins are nonadditive metadata evidence. Exact reader0b8ea fullsource-text and sanitized private-preservationf8bb descriptor now have specific b7a07b70 source clearance; existing983d metadata-reader controls are reused, not rerun. Publisher04 source3f13aa52/guard admissiond219 isnowcompleteinscope; finalC29 companion selection/publication remains pending andearlier02/03findings remainhistory. The private capsule/RESULT/membermanifest remains NOT_PUBLIC.

Current receiving durable space is below the unchanged32MiB+64KiB native admission threshold. Root requested an existing authorized private persistent location with at least256MiB free; no pruning, new paid service, reserve weakening or public raw upload. After receiving space is provided, root must restage/readback exact preparations/dependency references, bind the changed receiving configuration and independent admission, obtain fresh recovery approval/current held-state readback and record explicit root GO. Closing/reopening the terminal must attach to the same durable operation; storage absence does not stop code/source/metadata work.

External readiness spec114 still has no declared Windows capability, secrets, outbound identities or runtime variables. The original22:19:00Z estimate is preserved; measured read-only interval is22:18:05–22:19:44UTC per896f9cd9. Network access does not qualify tenant/principal or actualCI/device/backend routes. No activation or credential provisioning occurred. Original realWindows/GitBash/mintty/PowerShell, protectedCI, authenticatedGraph/Azure, devices, persistentOSscheduler, containment/crash, keycustody/AppSec and accountable organizational approval procedures/owners below remain required. Laboratory completion: IMPLEMENTED/pending; platform: BLOCKED; organizational production approval: BLOCKED.

Next action is the existing-private-space decision and exact remaining timing/recovery/corefactory admissions; actual normal32 starts at reviewed recovery, not the consumed apply. Source gate02 2,307strict pass, boundedperformance and independently admitted modeled-runtime64checks/34commands/10LinuxPTY remain reused at exact scope, with firstgateFAIL/target9PASS and all raw omissions preserved. Do not repeat them absent relevantchange/requiredgate.

Safe inspected help route (no helper/tool/native dispatch):

```sh
/workspace/intune-runtime/bin/python -I -B /tmp/intune-c25-native-extra-modes-profile-20261011-02/loader/qualify_fresh_modes.py --help
```

No apply/recovery activation command is approved here. Use the exact private configuration/admission protocol after receiving-capacity/root decisions; any changed bytes or receiving path need a newly pinned reviewed contract. Optional Wally remains read-only;87completed reviews/nine timeouts/no demonstrated benefit retain their original scopes.


C29 final admitted-source/preparation supplement (current known increment): additional fresh-mode03 loader b98c4e/profile8b00/outer966349/config72974a, exact a665e0c0 public admission (325metadata assertions/100 detached negatives, all32native actions NOT_STARTED) and four selected source-text/readme/disposition files are included. Candidate02 actual pre-dispatch Namespace-shadow AttributeError FAIL5f3b971f and earlier reader errors remain preserved; only three route-local references changed. These are preparation controls, not executed service/native or product counts. Exact publisher04 source3f13aa52 (14,929bytes) and d219e053 admission now pass PUB01–04 primary-error/environment/origin/physical-ancestor guard/source scope;12+8metadata fixtures and reused real79file C28read-only validation do not establish future Git/HTTP publication. Only publisher04 is selected; previous02/03 remain historical.

A separate currentC25 product gap was discovered by source inspection: known-host-completed work with a normal released lease after archive failure lacks a dedicated restart-readback factory. Actual entrypoint `intune_iac.worker_committed_readback.collect` consumes an exceptional committed-state recovery completion; never fabricate an exceptional release to reuse it. Root authorized a staged core factory repair/tests/recovery wrapper for C30. No actual negative receipt is invented here; the unchanged C25 source2307/performance/runtime scopes remain exact and cannot be borrowed for the newcore candidate. Independent failing-before/passing-after, application readback/recovery and required newsource/package gates follow its integration. Ordinary three-stage status/query/recovery closures and native executions remain separate pending work.

Previous exact C28 document follows.

# Increment28 — native qualification stopped; original failure preserved

The exact engineering candidate remains C25 `e3bdefe0b1ac0c58e46f9af3360970f8e47ae393`, tree `0bdbdeb3556acce23c8390abb20e835184880b27`. Source 17,956,520bytes / SHA `b18dd90c742e8082fef635c08807985ba631eb7634a2e4386c307daa3527917e` and runtime 1,520,542bytes / SHA `7ca39bc46cef9d8a699ea1885646fcecd281cd7e6677607b106267eb6a8fd84d` retain their tested identities. Completed source gate02(2,307planned/run/passed, zero exceptions), bounded Linux performance and independent actual modeled runtime64checks/34commands/10LinuxPTY remain precise unchanged scopes; no suite/timing/runtime replay or additivecount is requested.

C27 `3b9ec8e703e846605e7af4fe86191b7ac9e6fcd8`, tree `87f00c173c7a30d2d8eabf91bce4e39fae5c50f4`, is actually committed/published on `continuation/r4-20261007`, main unchanged, and all 31 reviewed sourcepaths have anonymous exact-byte readback. [The C27 publication](continuation-evidence/20261011/checkpoint28/checkpoint27-publication.json) and [readback](continuation-evidence/20261011/checkpoint28/checkpoint27-readback.json) record that scope. This proposed C28 needs its own commit/publication/readback; it cannot borrow C27 success.

New actual native run01 **FAIL / STOPPED_UNEXPECTED_FAILURE**, receipt SHA `7bdc4bb056373f2741b9a6da20063b7c157b2fc2cb0f3b8382561c93a1b526df`. The outercontroller records five completed actions: validate, adoption, ordinary-prepare, ordinary-service and ordinary-restore. The sixth ordinary-fault-assignment action was attempted and exited1: scenarioFINAL-QUALIFICATION saysPASS and cleanup has no recorded failure, but external native_ordinary_linkage.py closed/canonical encoding raised `ValueError: unsupported qualification JSON value`; the PORTABLE-QUALIFICATION receipt remainsFAIL. These contrary subreceipts are preserved; scenario completion/cleanup does not establish full portable/native acceptance.

There are **38 planned native actions**, not38faultchecks or independent assertions: five controller-completed, one attempted failure and32 later unexecuted. The original producer `not_started_action_ids` includes the attemptedfailed sixth action; its list is retained verbatim with an explicit current classification, not silently corrected. Firstfive scopes and every eventual independent assertion count remain distinct from source/runtime/performance/PTY totals. [Failure metadata](continuation-evidence/20261011/checkpoint28/native-run01-failure-summary.json) includes exact source/profile/driver/portable/error/capsule pins.

The complete owned private raw capsule is durably preserved with readback: **2,361,697bytes**, SHA `2163f1244942ef2c45e583c900b6f3fcdb0386a8aadfbef80388a5f38e533987`,1,547typedentries,27literal links and nineSocketmetadata markers. Capsule receipt SHA `22bafd679c38c8f0ac4d34f3a9c138096e812cc1995b624ee5b463ef177930e1`. The earlier after-adoption capsule1,025,940bytes / SHA f2f405bd49053f5e399866106ed2d4877fe313831d282b6e0082ca94e5547dcb is retained separately. Capsules are private evidence, not publicly suitable or standalone runnable restores. Existing source/runtime/toolbytes remain separately pinned, Socketpeer state is not serializable, and external receipt/census/finalstatus remain alongside. These complete owned outputs do not recover265audit-absent historical roots/39unavailable receipts or close actor/helper/unexpected-file provenance.

The final outerdriver `cae6702be2fe4e1fa5736a69d1673403a5e91d198961101fef12ae5f17d45403`, config04 `3589fcc1818b9b6c74d3202a5081e3fbdfa1627df0df04fd1cda21fc46c772ee` and profile `214b7365fa5c6683be89887d36350305cf59e4b855fcf81d35dae4bf146a6774` have bounded predispatch detached admission `eac249c565788beb611b89d40ad43f0fb81be8f4723f38d79c8ac0842f1048a6`. NO01–NO04/original failed candidates and beforeafter controls remain retained; detached admission is not actual full journey PASS or organizational approval. Specific outer/source public copies are controlled by author/independentreview and are not assumed from this proposal.

The next dependency is a **focused external qualificationhelper contract repair**, then independent reconciliation of existing frozen rawmetadata with no repeated nativeoperation. Exact candidate/valuecontract/independent controls/publicsuitability are pending author receipts. Preserve the originalFAIL; never drop fields, loosen knownbad gates or replay consumed operations to get PASS. A changed helper requires a separately bound closedprofile before remaining actual actions. Resume remaining native fault/recovery/signed history and independently admit rawstate/service/operation evidence only after those exact prerequisites. The actual operating entrypoints remain trusted `AdoptionJob.run`/`ServiceJob.run`; the terminal has no run CLI. [The execution sequence](EXECUTION-SEQUENCE-R4.md) retains precise next steps.

**Outcomes:** laboratory completion is not globally established; required whole native run01 failed and laternative/OSschedule/corpusdelivery remain. Platformqualification isBLOCKED; organizationalapproval isabsent. G01–G13 retain actual Windows/GitBash/mintty/PowerShell, protectedplatformchoice/CI, authenticGraph/Azure/backend/provider identities, enrolleddevices, installed independentOScollection, containment/keycustody/AppSec and accountableowners. Synthetic local Graph/Azure endpoints do not prove real tenant/service/device evidence. Wally remains optional/read-only; preserve87completed/ninetimeouts/no demonstratedbenefit and all original sixthreads/inputs/failures/qualification gaps.

Automaticapproval review rejected the isolated malformed-error providerrepair, citing possiblecybersecurityrisk without an exposed specificcommand/detail. Its unbuiltcandidate and nativefailures remain preserved; G13 staysblocked and no alternate repairroute is authorized.

Read-only resume:

```sh
cd /workspace/intune-continuation/work/projects/intune
git status --short
git log -5 --oneline
cat docs/EXECUTION-SEQUENCE-R4.md
cat /workspace/intune-continuation/work/evidence/epoch-20261007-r4/integration/c25-native-journey-resumed-20261011-01/RESULT.json
```

Independent stopped-prefix evidence admission now validates the precise original
FAIL boundary, with **111 nonadditive reader assertions**. [Its public metadata](continuation-evidence/20261011/checkpoint28/native-stopped-independent-admission.json)
is SHA `3b0d883d8d8a6ba41f358f4dc6980429500f4bf51c5fb60ba84b00c004f08101`;
the full private result is SHA `c4b0993f6c18645c79d7213fcceabd3d1ecfbed35eeeaf8e1988cd2af7e71f8c`.
The sixth action actually returned policy PUT204 and assignment403, left state
serial13 unchanged, and recorded `outcome_unknown` with a held lease and two
reservations. Expected partial-fault assertions pass; portable linkage and whole
native run01 remain FAIL. Host cleanup does not release those reservations or
resolve the uncertain operation. Metadata repair cannot authorize repeating its
consumed apply; explicit reviewed recovery remains a separate required route.

The initial fixture mapping remains unsupported, and this stopped prefix does
not qualify the authoritative source-authoring bridge. The first capsule covers
two completed actions; the final capsule covers retained attempted evidence,
not32 later actions or complete historical recovery. [Adoption stage classification](continuation-evidence/20261011/checkpoint28/adoption-stage-classification.json)
separately preserves first-plan host verification versus adopted_verified job
and guarded independent completion. Reopened history records independent
adoption/exact capture; no stale authority defect is demonstrated. Generic
verification labeling remains a presentation ambiguity, without a claim about
every visual TUI label. Twelve classification assertions,15 contrary reader
controls and three preserved reader errors remain separate and overlap other
counts; none increases a product or native test total.

The [exact coordinator source text](continuation-evidence/20261011/checkpoint28/native-orchestration/native-lab-orchestration.py.txt)
is specifically reviewed qualification-only documentation,50,011 bytes/SHA
`cae6702be2fe4e1fa5736a69d1673403a5e91d198961101fef12ae5f17d45403`.
[Its source disposition](continuation-evidence/20261011/checkpoint28/native-orchestration/SOURCE-DISPOSITION.json)
retains NO01–NO04 root causes and failing-before/passing-after detached controls.
The exact original source bytes are copied as.py.txt, outside the C25 runtime.
Private config/profile/host/GO/nonce/raw captures/state/plans/approvals/journals
and capsules remain omitted. Public source suitability is bounded and does not
establish AppSec, actual complete native qualification or organizational approval.

---

## Prior increment27 — preserved unchanged historical scope

# Increment27 — exact C25 source gate, bounded performance and verified source publication

The engineering candidate remains **0.9.0, C25**,
`e3bdefe0b1ac0c58e46f9af3360970f8e47ae393`, tree
`0bdbdeb3556acce23c8390abb20e835184880b27`. Its exact packages keep their C25
identity: source **17,956,520 bytes**, SHA-256
`b18dd90c742e8082fef635c08807985ba631eb7634a2e4386c307daa3527917e`;
runtime **1,520,542 bytes**, SHA-256
`7ca39bc46cef9d8a699ea1885646fcecd281cd7e6677607b106267eb6a8fd84d`.
Reconstruction, safe extraction, selected 3,354-file Git linkage and exact
rebuilds pass their integrity scopes. This documentation checkpoint does not
relabel the packages or claim an updated runtime/native release.

The NEW exact extracted-source required gate02 **passed 2,307 planned/run/passed
methods**, with complete core and zero failures, errors, skips, expected failures
or unexpected successes. Its actual receipt is SHA-256
`cb3c66aebfc2a81aa31c7d31a8e19eca510e55f167a2f8c1fae5e4ba297ed88d`;
[source-gate02 metadata](continuation-evidence/20261011/source-gate-attempt-02.json)
retains exact source/archive linkage and the independent raw result/log pins.
The before/after namespace inventories are byte-identical, SHA-256
`36bd870fbab4759b2c3740ec4cc5aab6cc8068d1cd3f6d452b1c34a8c03c215d`,
and the source ZIP remained exact. This is the recorded local source-suite
scope; it does not establish the full native lifecycle, actual runtime journey,
Windows, live Graph/Azure/CI/device behavior or organizational approval.

[Gate01 remains FAIL](continuation-evidence/20261011/source-gate-attempt-01.json):
2,307 planned/run, 2,298 passed and nine required skips, with zero failures/errors.
Exact-source inspection found seven native-convergence methods defaulting to
`/tmp/intune-native-completion/tofu` and two native-completion methods hard-coding
that absent alias. A new byte-exact copy of the existing independently pinned
OpenTofu 1.13.1 satisfied that qualification interface without changing product,
provider, assertions or gates. The [targeted nine-method replay](continuation-evidence/20261011/qualification-context-targeted-nine.json)
passed with zero skips; it justified the mandatory complete new gate02 rather
than a union-based 2,298+9 PASS. Counts overlap and are never added across attempts.
The [namespace distinction](continuation-evidence/20261011/historical-namespace-distinction.json)
preserves the original missing 1.10.0/broker corpus and unresolved actor finding:
the new fixture is not recovery of that directory. Gate01's four observed Z/PID1
children were nonexecuting; no complete reap claim is made. Earlier original
strict03 remains unobserved; no new run recreates its old raw logs.

Exact C25 Linux performance/capacity now has independently admitted evidence:
source **1,037 CLI calls / 22 recorded checks / 37 gated samples**; runtime
**48 CLI calls/samples / 10 recorded checks**, including nine real Linux PTY
inputs for paging, search, immutable selection, inspection, settings, dictionary,
health and quit. Original wall ceilings 2/5/15 seconds, CPU 1.5/4/12 seconds and
RSS 256/512/768 MiB remain unchanged. Complete 100-object unpaged and 1,000-object
inventories through explicit 50-object pages are demonstrated; a complete
unpaged 1,000-object overview correctly rejects its byte bound. The observations
are synthetic/caller asserted and seeded history/denied variants are explicit
SQL fixtures. Three descriptive samples and uncontrolled page caches do not
establish a fleet SLA or comparative acceleration. The [summary](continuation-evidence/20261011/performance-summary.json),
[replay](continuation-evidence/20261011/performance-replay.md) and
[independent admission](continuation-evidence/20261011/performance-independent-review.json)
retain complete capsule/readback, original thresholds, independent SQL/negative
controls and 152 actual Git-blob measured dependencies. Fifty-six read-only
review assertions overlap other scopes. Both failed reviewer attempts remain;
only three SQLite header bytes differ after restore, while all 12 table schemas/
rows and original backup bytes are independently preserved. No product/timing
rerun occurred in that review. Only D12 performance, E01 local scale and G11
performance portions are updated; their whole requirements are not promoted.

C26 **`b7aedfa6b8e521aa09dbce7540d4770b4cfdbfad`** equals the published
`continuation/r4-20261007` ref; main remained
`4ba077d93fecbf5f893ee13ef972c839cf13883d`. The [publication receipt](continuation-evidence/20261011/source-branch-publication.json)
and [anonymous HTTP200 readback](continuation-evidence/20261011/source-documentation-readback.json)
prove exact bytes/hashes for 13 reviewed source documentation/inventory files.
This C27 write is awaiting its own commit/publication readback; it does not borrow
C26's publication result. Selected source publication is not full corpus delivery
or protected CI/deployment qualification.

Protected adoption/import recovery, source-v2 maintenance binding, sealed
no-acquisition observation, separately approved Plan /3 successor and portable
mixed history are already integrated. Current implementation bytes match C25;
older checkpoint12/19 implementation-pending prose below is historical. C21's
Plan3 operation `ccc821ee-32d2-4829-b8c6-511acb744487` has a historical native
no-change/state13/readback/history/PTY attestation at checkpoint22, bounded by
its original revision and now-missing raw dependencies. Failed consumed Plan2
remains unknown and is never replayed; observation cannot release a nonexistent
lease. A **new attributable recovery qualifier** has [API/artifact review](continuation-evidence/20261011/recovery-helper-api-review.json),
[scope-label rebinding](continuation-evidence/20261011/recovery-helper-label-review.json)
and [specific public text review](continuation-evidence/20261011/recovery-helper-public-text-review.json).
Its [source-text copy](continuation-evidence/20261011/native-recovery-plan-qualifier.py.txt)
is exactly 28,860 bytes, SHA-256
`aec945b139e94ab303fb52e4ca8129590cdb5cd58dbe7b05698343ffffef2100`.
It is qualification-only, outside the runtime and not the missing original
helper. Closed profile admission and actual native/fault/history execution
remain PENDING. Ten AST/30 JSON/static controls are scoped, overlapping reviews,
not native passes or additional strict tests.

**Next increment:** preserve the independently admitted exact-runtime evidence,
then activate only the independently reviewed complete native helper/tool/source
profile and drive adoption → ordinary-prepare immediately → bounded authoritative
change → exact approved apply → independent readback/convergence → interruption/
partial/committed-state recovery → signed history and actual PTY reopening.
[The current sequence](EXECUTION-SEQUENCE-R4.md) provides verified commands.
Pre-execution wrapper review found WR01–WR03 initial archive binding, trusted
input/creator pins and premature final-receipt weaknesses; original bytes and
[failed review](continuation-evidence/20261011/qualification-wrapper-review-before.json)
are preserved. Exact repaired wrapper admission and specifically reviewed source-text copies
are now recorded below. No native PASS is inferred from preparation; independent
runtime/native outcomes belong to a separate checkpoint.

The resumed audit found **265 absent historical scratch roots / 39 unavailable
pinned receipts**, with 27/28 original native helper members recoverable. Those
counts describe that audit; new attributable files do not reconstruct history.
F03/F09 remain BLOCKED. Historical three unexpected files/reappearance, actor
attribution, helper/bytecode provenance and missing raw evidence remain open.
C24's 2,304 result, 0.7.0's 1,141 and 0.8.0's 1,242 retain their exact original
scopes; none is added to 2,307 or rerun for this documentation update. Preserve
all six threads, original inputs, failures, skips and Wally's optional read-only
87 completed reviews/nine timeouts/no demonstrated benefit.

**Outcomes:** laboratory completion remains incomplete (exact native/fault/history
journeys PENDING); platform qualification BLOCKED; organizational production
approval absent. G01–G13 retain actual Windows, protected-platform choice/CI,
Azure/Graph identities/state, OS scheduling, devices, containment, key custody,
AppSec and accountable owner gates. G05 is not access-only: current final native
qualification and real platform scope both remain. [Publication omissions](continuation-evidence/20261011/publication-scope-27.md)
explicitly exclude 27 other helpers, raw inputs/artifacts, profiles/binaries/
private signer material and the complete private corpus. Root-authored new
wrappers/binding module are specifically admitted as the three exact source-text
copies below; 27 other helpers, raw inputs/artifacts and private profile remain
explicitly omitted.

Automatic approval review rejected the isolated malformed-error provider repair,
citing possible cybersecurity risk; no specific command or more detailed reason
was exposed. Its unbuilt candidate and failures remain preserved. G13 is still
a release blocker, and this checkpoint grants no alternate repair route.

Resume without restarting completed work:

```sh
cd /workspace/intune-continuation/work/projects/intune
git status --short
git log -5 --oneline
cat docs/EXECUTION-SEQUENCE-R4.md
cat /workspace/intune-continuation/work/evidence/epoch-20261007-r4/integration/c25-strict-resumed-20261011-02/RECEIPT.json
```


Repaired outer qualification wrappers now have **PASS_SCOPED** independent
admission, SHA-256 `c214a73cddd9a9919d0c5ff3708dc1c9233c4db4259ba81133e0e0aa7acfcb57`.
[The repaired review](continuation-evidence/20261011/qualification-wrapper-repaired-review.json)
retains 46 bounded binding/gate controls and eight failing-before/passing-after
primary-error probes; these overlap other reviews and are not added to test counts.
WR01–WR04 fixes bind exact initial ZIP namespace/types/bytes, trusted helper/input
and observed gate identities, final receipts after capsule verification, and the
original failure when secondary evidence recording fails. Original failed
reviews/pre-repair bytes remain preserved. Exact source texts are specifically
admitted as qualification-only documentation:
[binding](continuation-evidence/20261011/qualifiers/c25_package_binding.py.txt)
5,746 bytes/SHA `964ae8cded75ed1b5f06dcd49d911a7618b4e63a2b48a250697467d2e6ad5053`;
[runtime](continuation-evidence/20261011/qualifiers/qualify-c25-runtime-resumed-20261011.py.txt)
7,154 bytes/SHA `c2e099f6c07e77bc9427e87cd4cff023112ae9b4ca2e2ef6874b25390ecf7468`;
[native preparation](continuation-evidence/20261011/qualifiers/prepare-c25-native-resumed-20261011.py.txt)
10,891 bytes/SHA `c46e6fecf617cad13d3a3cff429154edf56a983d8b7ad294b95d1418166bef3e`.
They remain outside the C25 runtime and do not provide a complete standalone
private qualification profile or production worker authority.

Outer qualifiers require **unoptimized Python (`sys.flags.optimize == 0`)**.
Do not use `-O`/`-OO` or set `PYTHONOPTIMIZE`; `-B` does not itself override an
optimization environment. [Six detached exact/substituted input-pin controls](continuation-evidence/20261011/qualification-wrapper-pin-assertions.json)
passed with optimization zero. The prepared procedure and root invocations use
unoptimized Python; qualification asserts are input admission, not a production
authorization boundary. These controls are not additional suite/native counts.

Actual exact-runtime producer procedures `qualify-workflow.py`,
`qualify-terminal.py` and `qualify-workbench-connected.py` have now each exited 0.
The [producer receipt](continuation-evidence/20261011/runtime-journey-producer.json)
is SHA-256 `c5b8a28507eb270c9c259c957bbff3095c24417ffa7d1929288c0e346832398d`;
initial source/runtime extracts match their exact ZIPs and remain unchanged.
The [verified owned-output capsule receipt](continuation-evidence/20261011/runtime-owned-capsule.json)
is SHA-256 `c454a1168fe8e5062117faed33bf24718c90bf08bb2774fe1b6667c2db24bcf7`,
covering 284 members and 46,179,244 archive bytes, SHA-256
`1268bd9197d0354e3b1520b841c3cb1ec23a9494a905683376de34cba4ff454c`.
Independent runtime admission now passes the precise modeled-service scope
recorded below; retain its connected raw SQL/PTY/input outputs. The first two qualifiers internally discarded their
TemporaryDirectory raw intermediates, an explicit evidence omission; a complete
owned-output capsule does not recreate them. Exact closed native/fault/signed
history qualification remains **PENDING**. Later exact native/fault/history outcomes
belong to C28, with no global laboratory/platform/production PASS inferred.


Independent runtime admission is now **PASS for the precise local route scope**,
receipt SHA-256 `7085b2281bd14931835e941a3518aea23fc09316d01d44ad8546b6ad5c84792e`.
[Specifically public independent metadata](continuation-evidence/20261011/runtime-independent-admission.json)
is SHA-256 `43c3cdfa19d53f210535e16a8cb4b000a412d50895eaf4549e27b7b8cc102c74`.
Thirty-six independent stdlib/raw-capsule/SQL/PTY/literal reader assertions admit
the actual packaged connected journey: **64 named checks / 34 commands / ten
Linux PTYs**. Independent postconditions preserve stable identity, assignments,
exclusions/filters across adoption and bounded setting change; verify exact
modeled approval/journal/replay rejection, exactly two modeled writes,
interruption/readback/no-change convergence, history/last-good denied reads,
health denominators and populated migration data. Closed-terminal collection is
a **finite explicitly invoked modeled schedule**, not an independently installed
persistent OS scheduler. Workflow eight parsed CLI results/11 harness checks
and the standalone wizard PTY retain their narrower evidence scopes; deleted
TemporaryDirectory state/child/verify streams remain unavailable explicitly.
These counts overlap source tests, other route checks and old evidence; never
add them into a test total. No new suite/native/timing rerun occurred in the
independent review. Exact closed native/fault/signed-history qualification,
missing historical corpus and external host/service/backend/CI/device/security
and organizational decisions remain pending or blocked. All-required local
implementation completion, platform qualification and production approval are
**not established** by this admitted modeled-service route.

---

## Prior increment26 — unchanged historical status

The complete original checkpoint26 below is retained unchanged. Its bold
“no C25 ... performance PASS” statement describes that earlier increment;
current precise source/performance/publication scopes above supersede it.
Original old paths, failures and unresolved provenance retain their history.

# Current R4 continuation checkpoint — 2026-10-11

The engineering candidate is **0.9.0, C25**,
`e3bdefe0b1ac0c58e46f9af3360970f8e47ae393`, tree
`0bdbdeb3556acce23c8390abb20e835184880b27`, on the dedicated
`continuation/r4-20261007` branch. The exact source is descended from verified
0.8.0 `289ee9477372825aad848f4482cf681c2ff43b02`. Do not overwrite C25 with an
older snapshot. The root coordinator owns the new documentation checkpoint and
its branch publication; no remote success is asserted before checked readback.
A documentation checkpoint after C25 does not relabel older tested artifacts.

Increment26 reconciles the resumed environment. The retained current ledger has
92 rows:1 PASS for baseline recovery,75 IMPLEMENTED,15 BLOCKED and1 UNSUPPORTED.
F03/F09 are nowBLOCKED on observed missing raw recovery evidence; their earlier
IMPLEMENTED values and all original nested statuses/contrary evidence remain
verbatim in preserved records. The latest
candidate/current artifact fields are corrected independently of historical
qualification applicability. Read the new C25 requirement matrix and direct
reference audit under
`work/evidence/epoch-20261007-r4/branch-resume-20261011/ledger-reconciliation-01/`.
The audit examined2,932 references/318 canonical path-hash pairs:279 exact
available matches,39 missing original `/tmp` targets, zero byte mismatches.
The independently recorded workspace audit found265 of360 mapped roots absent,
all under `/tmp`, and95 present under `/workspace`. This is a material full-R4
corpus preservation gap. The absence is observed; deletion actor/cause is not
independently established.27 of28 closed native helper members are recoverable
at their exact pins; `native_recovery_plan.py` is not found in bounded retained
source. No clean file-set closure or complete new-native profile is claimed.

Initial audit01's two work/docs namespace false-missings are explicitly
corrected in audit02/03.108 of219 primary source-dependency records match the
current bytes;111 differ. Many primary records predate later scoped receipts;
these figures neither discard later evidence nor establish transitive reuse.

C25 source and runtime ZIPs were freshly reconstructed on2026-10-11 into
`work/releases/continuation-0.9.0-r4-c25-restored-20261011/`. The source is
17,956,520 bytes, SHA-256
`b18dd90c742e8082fef635c08807985ba631eb7634a2e4386c307daa3527917e`;
the runtime is1,520,542 bytes, SHA-256
`7ca39bc46cef9d8a699ea1885646fcecd281cd7e6677607b106267eb6a8fd84d`.
Their bytes match the retained original C25 package record. The new
`RECONSTRUCTION-RECEIPT.json` records actual argv and exact source/tree linkage.
This restores package availability only. New independent verification records safe source/runtime extraction,3354
selected Git-linked source files,3355 sourceZIP/300runtimeZIP members and exact
rebuilds. Its receipt SHA-256 is
`25c6c039c2d48ceb0455b7d5858e07b44b2e4ee4042cada0ac4124cd3f0b6d8e`.
These are package integrity scopes; no suite/native outcome is inferred.

C24's2304/2304 required gate and CLI/PTY/connected results remain recorded
historical attestations in C25, the independent package review and prior ledger
integrity record. Their original raw `/tmp` receipts/logs are currently missing.
The prior C25 strict03 run's final result has not been observed. **No C25 strict,
complete native journey, performance or full-delivery PASS is claimed.** Missing
scratch evidence is a preservation gap, not a newly observed failed test; do not
manufacture or reconstruct historical logs from expected outcomes. Preserve the
C22 failure, all repair-before/after records and the exact old artifact pins.

The earlier descendant cleanup blocker has explicit preserved root cause and
repair evidence. The old runner sent SIGKILL then waited only for the exited
direct child, returning before descendant termination was confirmed. The
repair establishes bounded nonexecuting process/task state while group identity
remains anchored, then reaps the direct child. Original repeated R!=Z failure,
independent44-case before/15 failures,48-case after/zero failures and20 original
passing repeats are retained. `HISTORICAL-REUSE-READBACK-01.json` checks exact
existing receipt bytes without replay. Preserve the1,141-test0.7.0 and1,242-test
0.8.0 results at their own revisions. Neither old cleanup proof nor those
results qualify changed C25 supervisor bytes or native Windows.

The first remaining local dependency is qualification of the available exact
C25 artifacts, after restoring the required pinned qualification-tool context.
Use the discovered scripts in `EXECUTION-SEQUENCE-R4.md`. The exact original
strict-driver bytes were recovered and an attributable path-only adaptation
with existing qualification-tool pins was prepared/negatively checked. A NEW
full C25 gate remains required after the current quiet performance window and
reviewed source publication. The recovered wrapper does not recover old logs.
After the required gate is quiet and passes, construct a new exact-source
closed native profile from its retained admission, first recovering the exact
missing helper or preparing/independently qualifying an attributable new
replacement; its narrower provenance scope must remain explicit. Include ordinary
partial/committed-state/reverse-description fault routes. Fresh adoption is
followed immediately by ordinary-prepare, before maintenance changes that
fixture. Preserve consumed unknown operations; no old approval or saved plan
is replayed. Finish signed history/PTY and preregistered quiet performance, then
complete nine-layer evidence/delivery verification. Source publication alone
does not deliver the complete recovery corpus.

Public branch metadata is prepared at these explicit relative destinations:
[workspace availability](continuation-evidence/20261011/workspace-availability.json),
[reconstructed packages](continuation-evidence/20261011/reconstructed-packages.json),
[package verification](continuation-evidence/20261011/reconstructed-package-verification.json),
[source review](continuation-evidence/20261011/source-review.json) and
[source/history/package review](continuation-evidence/20261011/source-history-packages-review.json).
The coordinator copies specifically reviewed metadata into this checkpoint;
those receipts contain no raw tenant captures, credentials, state or plans.
These links make the public continuation evidence reviewable, and do not claim
public full-corpus delivery or a successful remote upload before readback.

**Outcomes:** laboratory completion remains incomplete; required platform
qualification remains blocked; organizational production approval is absent.
G01–G13 in `EXTERNAL-GATES-R4.md` give specific environments, authorizations,
procedures, expected evidence, recovery and owners. Native Windows/Git Bash/
mintty/PowerShell, installed protected CI/service, real Graph/Azure identities/
state, OS-scheduled collection, devices, destructive containment, key custody
and AppSec/accountable approval keep distinct gates. Existing source-publication
authority grants no deployment, tenant mutation, credential provisioning,
privilege expansion or production decision. Wally remains optional/read-only;
87 completed reviews, nine timeouts and no demonstrated benefit are preserved.
The three original unexpected files/reappearance, actor attribution and later
helper/bytecode provenance findings remain open.

Automatic approval review rejected the isolated malformed-error provider repair,
citing possible cybersecurity risk; no specific command or more detailed reason
was exposed. Its unbuilt candidate and failures stay preserved. G13 remains a
release blocker, and this reconciliation grants no alternate repair route.

Resume the exact available candidate without starting work from scratch:

```sh
cd /workspace/intune-continuation/work/projects/intune
git status --short
git log -5 --oneline
cat docs/EXECUTION-SEQUENCE-R4.md
cat /workspace/intune-continuation/work/releases/continuation-0.9.0-r4-c25-restored-20261011/RECONSTRUCTION-RECEIPT.json
```

The following original checkpoint prose is retained historical context. The
current scope and availability statements above supersede its runnable `/tmp`
paths and any older continuation claims.

---

# R4 initial reconciliation checkpoint

This is a continuation checkpoint, not a completed milestone or release.
Source baseline is **0.8.0**, commit
`289ee9477372825aad848f4482cf681c2ff43b02`, on dedicated branch
`continuation/r4-20261007`. The root coordinator recorded a clean starting tree
in `work/evidence/epoch-20261007-r4/BASELINE.json`. No older source was restored
over newer work. The current implementation agents may have subsequent
uncommitted changes; inspect Git status before continuing.

The complete user-supplied contract is persisted byte-identically at
`work/docs/INTUNE-WORKBENCH-STRICT-CONTRACT-20261007.md` and this project's
`docs/STRICT-CONTINUATION-CONTRACT-R4.md`: **26,294 bytes**, SHA-256
`88192ac7e2627368fedcbc01e8f1faeb0f26120983f70bcdbb89e87bbdcb2c5a`.
It supersedes the earlier “brief not yet supplied” observation without rewriting
that historical receipt.

`docs/CONTINUATION-R4-LEDGER.json` records 91 requirement rows with the requested
identity, profile, status, evidence class, source/artifact applicability,
procedure, evidence, environment, limitation, next action and owner fields.
It includes 18 explicit fault families. Only baseline continuation linkage is
PASS; new implementation/qualification remains NOT_STARTED or externally
BLOCKED until actual receipts justify an update. Status here does not erase
existing implementation or original qualification. The initial ledger is also
saved unchanged in `work/evidence/epoch-20261007-r4/reconciliation/INITIAL-LEDGER.json`.

The historical R3 acceptance ledger remains unchanged: **310,833 bytes**, SHA-256
`7c1e5839c1c470199fd31f849b67730f7236c2a61e7375b1a6075e0e99f8b6a7`.
The baseline 1,242/1,242 exact-source strict result, 64-check/34-command/10-PTY
connected journey and separate 1,141-test R2 result were **not rerun**. Failed
final01/final02 candidates, cleanup/acquisition repairs and failed intermediate
repairs, all six threads, raw inputs, old skips, Wally negatives, unexpected
files/reappearance and commit-actor gaps stay immutable. The original three
unexpected files and attribution gap are not closed by successful new work.

The first unblocked dependency is accurate repository/observed/proposed/coverage
views, distinct collector/provider-state/deployment baselines, and complete
declared cross-stack ownership. Extend the existing store and application
entrypoints. Independently challenge merged-only, portal-only and simultaneous
changes, state-absent objects, conflicting owner, stale index, incomplete
collection, bad IDs/targeting/types and collection semantics. Then integrate
the common protected worker/backend contract; implement authentic reader and
independent scheduling; present those shared contracts in the visual workspace;
qualify required native routes; and qualify/package the exact reviewed release.
These dependencies and scoped external gates are recorded in the ledger.

Read `docs/OPERATING-PROFILE-R4.md` before expanding support. Native Windows/Git
Bash is a required external route, not removed because this host is Linux.
Current source pins are OpenTofu **1.13.1** and Atmos **1.230.1**; older
1.10.0/1.199.0 lab/fixture contracts retain historical scope. The new production
CI choice is unresolved: GitHub Actions is the existing documented candidate,
Azure DevOps Pipelines is unconfirmed. Implement the common worker contract
locally first; deployment needs the actual organizational choice and applicable
authorization. Do not disable the restricted lab network boundary.

The actual launcher is `scripts/intune-iac.py`. Root, `workbench`, `provider`,
`capture` and `target` help were invoked with the retained runtime; all five
exited zero. Raw stdout/stderr, argv and hashes are saved in
`work/evidence/epoch-20261007-r4/reconciliation/HELP-RECEIPT.json` and sibling
files. These are entrypoint discovery records, not tests or service evidence.
No new qualification command is claimed until its implementation and help exist.

Resume by reviewing current status and the preserved plan:

```bash
cd /workspace/intune-continuation/work/projects/intune
git status --short
git log -5 --oneline
cat docs/CONTINUATION-R4-CHECKPOINT.md
cat docs/OPERATING-PROFILE-R4.md
/workspace/intune-runtime/bin/python -B scripts/intune-iac.py workbench --help
```

At this checkpoint the ledger agent changed only four project documentation
files (`STRICT-CONTINUATION-CONTRACT-R4.md`, `CONTINUATION-R4-LEDGER.json`,
`CONTINUATION-R4-CHECKPOINT.md`, `OPERATING-PROFILE-R4.md`), the work-level brief
copy, and new `reconciliation/` evidence. The agent did not commit; the
coordinator owns the integrated durable commit. New candidate/artifact
identities remain null rather than incorrectly borrowing baseline hashes.

The initial reconciliation's structural checks validate required fields,
normalized statuses, unique IDs, dependency references, existing source paths,
brief equality and historical reference hashes. They do not count as product
tests. Save new independent product assertions and failed attempts in new R4
subdirectories, update exact revision/artifact applicability, and commit a
durable checkpoint after each meaningful increment.

**Outcomes:** laboratory work under the new contract is incomplete; required
platform qualification is blocked on concrete native environments and approved
service scopes; organizational production approval is absent. Continue all
independent local work. No production change, credential provisioning, platform
administration, paid resource or privilege expansion is authorized by this
checkpoint.

## Increment 1 — exact capture replay repair

The initial two new regressions failed: sequential replay produced two observations; four concurrent imports produced four. Publication now serializes duplicate detection and insertion in one SQLite write transaction. Every import attempt remains visible, exact raw capture bytes and original timestamps remain unchanged, and duplicates reference the original observation without refreshing it. The changed-scope run passed 37 tests (overlapping existing suites; not added to the historical strict count). Before/after argv, output and source hashes are in `work/evidence/epoch-20261007-r4/capture-reimport/`.

This commit checkpoints the store repair, its two actual-entrypoint/concurrency regressions and the R4 contract/ledger/profile. It is not an integrated R4 release. Additional working-tree files for views, authenticated collection, visual presentation, backend and worker are being implemented on the same continuation branch; preserve them and inspect `git status --short`. The complete old 1,242-test suite has not been rerun. The new baseline/pending reader evidence-class and inert artifact-kind plumbing is additive; imported evidence remains non-authoritative.

Resume this repair with:

```bash
/workspace/intune-runtime/bin/python -B -m unittest plugin_tests.test_capture_reimport_r4 plugin_tests.test_capture_adapter plugin_tests.test_workbench_capture_store plugin_tests.test_workbench_paging
```

Continue integrating the pending A/B/C/D lanes and independent acceptance. This checkpoint does not close the milestone, service, native Windows or production gates.

## Increment 2 — integrated local implementation, native boundary still in progress

Parent commit is `984b8d491d54a4805d1fb2d925b684131ded0373`. This increment
records the four views and real local state ownership scan; pinned Git object
verification; versioned field semantics and source patch preparation; common
protected worker and Azure state contracts; authentic-reader implementation
and independently invocable scheduler adapter; visual shared-engine workspace;
native Windows qualification preparation; and private encrypted archival.
`CONTINUATION-R4-LEDGER.json` now records implemented scope, exact file hashes
and receipt hashes. Its null final-applicability fields are intentional until
committed/package qualification establishes them. This is not a release.

New actual application routes include `workbench views`, `repository-import`,
`ownership-scan`, `source-acceptance-propose`, `observer-create/run/status`,
`observer-scheduler`, `workspace`, `worker prepare/review/run/status/attach/
cancel/reconcile`, and `artifact seal/inspect/restore`. Inspect each route's
`--help`; argument schemas in the corresponding R4 guides are authoritative.
The text workspace also supports `views-page` with retained global filters.

Scoped evidence lives under `work/evidence/epoch-20261007-r4/`: `views/`,
`observation/`, `visual/`, `protected-worker/`, `azure-backend/`,
`native-host-preparation/`, `artifact-vault/`, `terminal-interrupt/`, and
`independent/`. Independent candidate checks demonstrated distinct comparisons,
ownership/field negative controls, closed-terminal observation and capture
restore, exact local worker approval/state effects, and the visual intentional
change/lost-response/reopen/reconcile journey. These independent grouped
assertions and overlapping developer suites are not one combined test total.
Receipts identify which exact candidate each result applies to.

The original duplicate-capture repair also passed 37 checks from an exact clean
checkout of `984b8d4`; see `capture-reimport/committed-01.json`.
A new real SIGINT-inside-SQLite-callback reproducer failed before repair:
SQLite translated KeyboardInterrupt to a database error and the terminal read
another command. The terminal now retains interrupt intent outside the callback
and restores the original signal handler. `terminal-interrupt/before.stderr`
and `after-01.stderr` preserve the counterexample and passing changed-scope run.
Independent active-callback replay is recorded separately; idle SIGINT is not
substituted for it. The earlier visual timeout remains preserved.

Active working-tree lanes excluded from this checkpoint include the Unix/TLS
broker, Docker host, native provider/Atmos integration, and persistent queue
review metadata. Preserve their files and evidence. The broker's Graph-PUT
mislabeled-as-lease negative was independently found and repaired, with original
and passing counterexamples retained. Actual Atmos 1.230.1 probing found an
advertised `--from-plan=...` form that attempted a fresh plan and stopped at EOF;
no mutation occurred. An exact saved-plan route must be proven before admission.
The existing restricted laboratory network boundary remains intact.

Resume the integrated local changed scope with the retained Linux interpreter:

```bash
git status --short
git log -3 --oneline
INTUNE_TEST_VALIDATOR_LIBRARY=/workspace/intune-continuation/work/evidence/epoch-20261005/approval-prerequisite/libsodium.so.23.3.0 /workspace/intune-runtime/bin/python -B -m unittest plugin_tests.test_workbench_views_r4 plugin_tests.test_observation_reader_r4 plugin_tests.test_observation_jobs_r4 plugin_tests.test_workbench_tui_r4 plugin_tests.test_terminal_interrupt_r4 plugin_tests.test_protected_worker_r4 plugin_tests.test_azure_backend_r4 plugin_tests.test_native_host_contract_r4 plugin_tests.test_artifact_vault_r4 plugin_tests.test_capture_reimport_r4
```

Continue native host/broker/provider integration, persistent queue metadata,
independent review and exact final-byte journeys. Then run required release
gates, reproducible packaging and public/saved readback. Do not rerun the entire
old strict suite simply to increase a count. Required external evidence still
includes native Windows/Git Bash and PowerShell; chosen CI controls; authorized
disposable Intune lifecycle and independent tenant/principal readback; real
Azure identity/state; enrolled pilot devices; approved hostile/crash host tests;
and AppSec/operations/risk approval. No real tenant or platform write was
authorized or executed by this increment. Laboratory completion remains
incomplete, platform qualification blocked, organizational approval absent.

## Increment 3 — persistent review, bounded history and native host preparation

Parent commit is `03d7096edcb939ddd3b077f78211c170dfecf065`. This checkpoint
preserves immutable queue review metadata with concurrent-update rejection,
policy-bound reporting gaps, shared ownership evidence in the inspector,
versioned dictionary provenance, portable parser/host readiness gates,
bounded recent history and native host/provider adapters. It also repairs
archival native initialization and parent-directory replacement races.
The commit receipt under `integration/COMMIT-03.json` records the resulting
commit, explicit Git actor/argv, exact files and remaining working tree.

The root changed-scope integration run passed **109 tests** in 12 selected
modules; raw output is `integration/increment3-precommit.stderr`. The separate
history scope passed **31 tests**, including actual CLI and Linux PTY navigation
over 1,001 retained observations and workflow import referencing the oldest
snapshot. These runs overlap other evidence and are not summed into a new
strict-suite count. The composed history run's earlier 79/80 result is retained:
the failed health fixture rounded a timestamp into the future. The fixture now
uses its serialized time; the product's future-evidence rejection is unchanged.

Independent archival review reproduced two ancestor-replacement races before
repair. Descriptor-relative no-follow traversal now keeps reads and publication
bound to the held directory inode. Ten focused tests and three independent
native-crypto controls pass; old failures and a test invocation missing its
pinned library variable remain in `artifact-vault/`. This does not provide
same-account hostile-process isolation or encrypt the running SQLite/job volume.

Actual pinned Atmos/OpenTofu/provider work against local TLS fixtures completed
import, an unchanged first plan, one description correction, exact saved-plan
application, independent policy/assignment fixture readback and convergence.
The valid Atmos invocation uses separate `--from-plan --planfile` arguments.
The advertised combined form that replanned and stopped at EOF is retained.
Nine actual Docker host checks cover restrictions, native invocation, timeout,
output limits, interruption, controller loss and cleanup. Neither fixture nor
container results establish authenticated Azure/Intune platform qualification.

A separate native negative uncovered a real provider robustness defect:
malformed Graph error content causes an SDK nil dereference. Conformant 400/403
errors return ordinary diagnostics; all three preserve exact state bytes with
zero Graph writes and zero OOM kills. The isolated source candidate is untested,
and no replacement binary exists. Automated agent execution rejected the repair
task for possible cybersecurity risk without identifying a specific command.
No retry was attempted. See
`worker-provider/provider-negative/PRESERVATION-STOP-RECEIPT.json`; this remains
a release blocker, independent of the valid successful local lifecycle.

The exact detached checkout of commit
`2b0bcb998fbba49a8a232174c1858da162639957` then ran 144 selected tests and
reported three import errors: native provider tests require `worker_broker`,
which was intentionally left in the active integration lane. The other 141
completed without assertion failure; the run as a whole is **FAIL**, not a
qualified checkpoint. See `integration/INCREMENT3-COMMITTED-CHECK.json` and raw
logs. Commit the complete broker/service dependency and replay this required
scope; do not remove the three tests or reuse the working-tree109 result as an
exact-commit pass. The detached checkout remained clean.

Native Windows is **UNSUPPORTED at implementation level**, not merely waiting
for a test host. Capability checks now explain missing storage/security
primitives and reject before creating a store. Native qualification records
functional cases as unsupported/blocked even when these negative gates pass.
Linux import-denial probes do not substitute for Windows/Git Bash/mintty or
PowerShell evidence. An isolated Windows private-storage component is the next
unblocked implementation dependency; the Linux path remains unchanged.

Active work excluded from this commit includes native broker lease/metadata/
chunked-body integration, authenticated fresh-read preconditions, the protected
service orchestrator, and the isolated Windows component. Preserve their files.
The broker's independently reproduced metadata-effect admission failure stays
open until its owner records repair and independent replay. Source/runtime
packages remain version 0.8.0 pending a reviewed final candidate; no R4 release
or public readback is claimed.

Resume at the actual checkout and inspect current work before executing:

```bash
cd /workspace/intune-continuation/work/projects/intune
git status --short
git log -3 --oneline
/workspace/intune-runtime/bin/python -B scripts/intune-iac.py doctor
/workspace/intune-runtime/bin/python -B scripts/intune-iac.py workbench history-recent --help
```

Continue service/broker/precondition integration, independent boundary review,
final source-bound journeys, release gates and reproducible layered recovery.
The CI platform choice remains pending; no tenant or platform change is
authorized. Laboratory completion remains incomplete, platform qualification
blocked, and organizational production approval absent.

## Increment 4 — protected service composition and persistent evidence

Continuation parent is `2b0bcb998fbba49a8a232174c1858da162639957` on
`continuation/r4-20261007`. The next commit receipt in
`evidence/epoch-20261007-r4/integration/` records its exact resulting commit,
file list and actor. This is an implementation checkpoint, not a release.

The protected service now has independent exact-manifest signatures, external
one-use consumption and ownership, fixed native broker routes, fresh sealed
Graph preconditions, computed native state admission, durable lease recovery
inputs, independent state/Graph reconciliation and full execution-runtime
identity. Terminal preparation/observation cannot create execution authority.
The real controller rechecks its complete reviewed runtime before execution;
read-only preparation can run from a different terminal process.

Independent `independent/service-native-01/RESULT.json` passed a connected
Docker/relay/TLS journey with exact signature, wrong-reviewer rejection,
terminal detach/reattach, literal external-state assertions, cleanup and replay
denial. Its 23 assertions include six setup assertions; do not add it to suite
totals or describe it as native provider/live Azure/CI evidence. Broker/state
focused scope is 46 tests, and the read-only expired-lease inspector has five
tests. Receipt scopes and source hashes remain separate.

`worker-provider/native-service-prepare-01/receipt.json` preserves actual pinned
Atmos/OpenTofu/provider Azure-protocol initialization/import, no-change first
plan and a description-only saved correction: 85 fixture requests and 11
independent preparation assertions, zero Graph apply writes. The signed native
composition then exposed a failure: attempt01 lacked the explicit pinned
libsodium location and was rejected before dispatch. Attempt02 consumed exactly
one dispatch, returned native exit1, removed its container, and retained
`outcome_unknown` plus native lease recovery evidence. Its 101 fixture requests
and failure receipt remain unchanged. Diagnose the concrete error and preserve
the previous state/lease before any new isolated attempt; a passing simpler
transport journey does not close this native composition gate.

Workbench `service-link` persists exact tenant/object/manifest navigation.
`views` exposes the protected proposal and journal, and compares a deployment
only against its exact independently published capture. Unknown execution stays
separate. Unsupported mapping exposes literal raw captures, timestamps and
blockers without replacing normalized last-good values. Development evidence:
33 related tests plus one newly added unsupported-capture test, not overlapping
aggregate claims. Missing validator configuration, fixture mistakes and a
misspelled test-module command are retained in `service-views/attempt01/`;
corrected commands pass in `attempt02/`.

Inactive native Windows directory/storage components and native harnesses are
implemented. Their local state-machine tests do not establish native Windows
behavior. Functional Workbench Windows support remains UNSUPPORTED pending
store integration and actual Windows/Git Bash/mintty/PowerShell evidence. A
missing namespace durability barrier retains artifacts and reports uncertainty.

Type-aware evidence extraction and the eight-layer recovery wrapper are being
qualified with literal negative-test links and control-byte filenames retained
inertly. All diagnostics must escape them. The outer manifest remains a template
until final R4 archive pins exist; it must fail before extraction when incomplete.
No final package, R4 public readback or complete file-set closure is claimed.

The 18 required fault families now have an independent assertion/source map at
`independent/FAULT-FAMILY-MAP-01.json`. Remaining local composition cases include
policy success with assignment failure, acquisition/evidence-recording
cancellation, reviewed restoration as a new operation and final integrated
workflow/ref controls. Earlier failures, provider SDK nil-dereference finding,
automatically rejected repair lane and provenance anomalies remain open.

Resume without rebuilding the baseline:

```bash
cd /workspace/intune-continuation/work/projects/intune
git status --short
git log -3 --oneline
/workspace/intune-runtime/bin/python -B scripts/intune-iac.py service --help
/workspace/intune-runtime/bin/python -B scripts/intune-iac.py workbench service-link --help
/workspace/intune-runtime/bin/python -B scripts/intune-iac.py workbench views --help
```

Next: complete native composition and missing fault controls; commit the whole
dependency closure and replay the earlier failed exact-checkout scope; then
qualify the exact final source/runtime packages and full layered recovery.
Laboratory completion is incomplete, platform qualification is blocked, and
organizational production approval is absent. Do not retry the separately
rejected provider repair task or turn a checkpoint into a finish-line claim.

The native attempt02 root cause was subsequently confirmed with a deny-only
native CONNECT capture: pinned Go clients emit the exact optional
`User-Agent: Go-http-client/1.1` header. The broker previously rejected it before
any upstream request. The narrow repair retains surrounding denials and has
failing-before/passing-after evidence. No policy/provider gate was weakened.

`worker-provider/native-service-journey-03/receipt.json` now passes the complete
local native composition: exact saved Azure plan, signed protected service,
network-none Docker/relay/broker, pinned Atmos/OpenTofu/provider, policy and
assignment writes, fresh Graph preconditions, computed state write and lease
release, independently authenticated laboratory Graph/backend readback,
reconciliation, persistent service-linked views, and a no-change second native
plan. Its 17 assertions and 33 broker requests are one scoped journey. Of 181
fixture requests, 85 belong to preserved preparation and 96 are new. None are
live tenant/CI/device evidence. Unsupported mapping of the complete raw capture
remains explicit; normalized comparisons are not invented.

Independent review then reproduced raw SQLite projection substitution under a
capture's unchanged digest label. `raw_capture_observation` now validates the
retained type-aware capture bytes, exact projection and artifact commitments
before service-baseline use. Independent `service-views-after-03/RESULT.json`
passes 14 assertions, including tampering, missing/changed pages and restored
exact bytes; before failures and evaluator errors remain retained. The current
seven local view tests pass. An additional useful raw-observation test class has
unresolved original actor attribution; root reviewed and retained it at
`service-views/ATTRIBUTION-OBSERVATION-01.json`, without claiming attribution
closure.

Final service component scope is 30/30 at
`worker-service/qualified-08/QUALIFICATION.json`; its earlier 27/30 failure is
retained. New inactive Windows SQLite snapshot code has 14 Linux contract
controls with recorded Win32 boundaries, not native qualification. Packaging
inventory check05 admits 3,185 source members and 193 runtime members. Recovery
helper scopes are 22 typed-extraction controls, 11 wrapper controls and six
inventory controls; independent eight-layer miniature reconstruction passes 12
assertions. These counts overlap other scopes and are not a release-suite total.

Native fault/restoration exercises are continuing in new fixtures after this
checkpoint. The old full-suite results remain unchanged; final integrated and
package gates are still required.

Increment4 committed as `beb9daf7424e42f30c2d58c02014b7568289a3ae` with
explicit actor, staged-byte and file-list receipt `integration/COMMIT-04.json`.
An exact detached checkout passed 221 tests in 16 listed changed-scope modules;
the tracked tree remained clean. This includes all three previously failing
missing-broker cases. It is not a replay of the complete older 144-test selection
or either historical strict suite. See
`integration/INCREMENT4-COMMITTED-CHECK-ADDENDUM.json` for the exact command and
scope. Further native fault controls, explicit exceptional recovery and inactive
Windows store integration continue beyond this checkpoint.


## Increment 5 in progress — visual evidence and bounded Windows persistence

The actual native journey was independently navigated through three Linux PTY
sessions and the complete no-TTY route. Seventeen assertions pass, including
selection of unsupported raw captures, exact setting ID 37 and targeting,
protected-plan review, same-operation reattach, duplicate-name immutable identity
and no journal mutation. Earlier missing selection/raw-value failures remain in
`independent/visual-native-before-*`; root repair/source/replay receipt is
`service-views/VISUAL-REPAIR-RECEIPT-03.json`. Unsupported mapping remains visible.

The reviewed inactive Windows store reuses the exact schema and query engine,
with native handle-bound persistence, intent/outcome receipts, bounded backup,
pinned restore and recovery only into a new copy. Independent fault injection
found primary errors masked by close failures, premature completed receipts and
a missing early restore host guard; failing-before and passing-after receipts
remain under `independent/windows-store-*`. Ordinary Windows support is still
UNSUPPORTED pending native implementation integration and real host evidence.
The Linux/recorded-Win32 component tests are not native Windows qualification.

Native signed historical restoration completed with a new plan and operation,
independent readback, state serial14-to15 and a second no-change plan. Native
assignment403 and cancellation during acquisition, policy write and state
evidence recording preserve uncertain/partial results, leases and ownership.
See `worker-provider/NATIVE-SERVICE-EVIDENCE-INDEX.json` and the separate broker
acquisition receipt; counts remain separate and overlapping. Explicit signed
lease recovery, narrow description-drift state admission and same-authority
successor transfer are being implemented and qualified separately. No original
approval or failed plan grants new execution authority.

Current durable parent remains `beb9daf7424e42f30c2d58c02014b7568289a3ae`.
The working tree contains this increment; the next commit receipt will record
its exact paths and actor. Resume with `git status --short`, this checkpoint,
and the latest `integration/COMMIT-*.json`, then continue the pending integrated
recovery journey and exact-package gates. Laboratory completion remains
incomplete; platform qualification and organizational approval remain blocked.

The narrow description-recovery state contract is now integrated with exact-type
broker/readback branches; ordinary drift rejection is unchanged. The one-shot
lease recovery module is also preserved in this checkpoint; concurrency and
actual TLS evidence is scoped to its recorded source. Successor transfer and
its cancellation ownership repair remain staged outside runtime pending review.
A new independent finding identifies laboratory capture export/context labels
as non-synthetic and template tool versions despite correctly limited typed
reader receipts. Historical captures remain unchanged; root is repairing future
labels without minting live authority from caller-supplied context.

An additional actual22-command source conflict journey passed11 independent
assertions: competing proposals bind the same inherited source, first reviewed
Git commit wins, stale patch/product proposal reject, and a freshly based
proposal still requires review and a fresh plan. Native-success healthCLI also
retains all endpoint/device unknowns and null denominators (five assertions).
No live service, device or protected organizational review is inferred.


Increment5 committed `e90ac88db3afe6995702ed545832b48f5c110941`.
`integration/COMMIT-05.json` records exact36files and root actor. Cached diff
check first rejected a surplus blank EOF; its beforebytes and failure remain
in `COMMIT-05-ATTEMPT-01.json`. Exact detached checkout passed200 tests in
12listed changed-scope modules,47.125seconds, trackedtree clean. This is neither
a complete strict suite nor final package qualification.

Increment6 continues beyond it. Native partial-recovery journey02 passes
20outcome assertions plus4transfer negatives: separately signed same-authority
transfer, cancelled prepared successor returns old reservations, fresh final
transfer/approval, exact native savedplan apply, independent Graph/backend
readback, reconciliation and secondnochangeplan. Original failure, approval and
policy binding remain.109new requests are separate from219inherited requests.
Exact runtime/harness linkage is alongside
`worker-provider/partial-recovery-journey-02/receipt.json`; a separate literal
18-check evaluator overlaps that scope and is not added to its count.

C02 is concretely BLOCKED for actual OS scheduler qualification: pinned
BusyBox cron launched zero observers, first under UID1000 and then in isolated
unprivileged UID0namespace where initgroups returnedEPERM. Owned daemons are
reaped and every attempt preserved. No capability was added. Local scheduling
adapter/finite invocations retain their valid separate scope.

New typed laboratory captures now accurately record synthetic provenance and
omit unobserved tool versions.100changed-scope tests and13independent assertions
pass; the production candidate gate and original raw bytes remain unchanged.
Old mislabeled captures remain a historical finding. Windows reader cleanup
repairs pass the unchanged5-check independent evaluator, including all-handle
cleanup and no partial publication. Inactive native integration remains distinct
from missing Windows qualification. Further concrete interruption cases and
final packaging remain active work; this checkpoint is not completion.

Checkpoint6 is ready for commit: the combined Windows/provenance adapter passed
167 targeted repository tests; unchanged independent provenance controls passed
13/13 on the combined bytes. An incorrect hash-only reviewer warning and its
exact-diff correction are retained. Independent partial-recovery review passed
22 assertions over the actual native journey; these overlap the journey scope
and are not added to it. Windows native qualification remains BLOCKED with zero
native checks on this Linux host. New committed-state recovery is staged for the
next increment and has not yet consumed a release approval. Resume from the exact
commit in `integration/COMMIT-06.json`, then finish that signed recovery and final
package gates. No production or organizational approval is established.

Increment6 committed `449d18056590419261cf4955463808a97992eaef`; explicit
actor/34-path receipt is `integration/COMMIT-06.json`. Exact detached source
passed215 tests in15 named changed-scope modules; trackedtree stayed clean.
Attempt01 only prechecked two incorrect module names and executed zero tests;
that discovery failure is preserved separately from the corrected test run.

Increment7 adds a distinct original-committed-state recovery capability. The
actual interrupted state14 operation used a new signed exact lease release and
an actual native second no-change plan. Its first completion rejected a stale
identity binding after native plan metadata changed the ETag. Only fresh
read-only identity/context completion resumed the same spent recovery. The old
failed outcome and dispatch count1 remain; state/Graph/apply were not replayed.
Ownership was released only after sealed readback, with final outcome explicitly
`service_state_converged_execution_unknown`. See the original failure and
`worker-provider/committed-state-recovery-resume-01/receipt.json`. Advanced-state
interruption of the separate description-recovery schema is still local work.

Native dictionary/read-only lineage integration passed66 scoped cases plus
seven unchanged independent controls after reproduced missing-API failures.
This is recorded-Win32/actualSQLite local evidence; nativeWindows remains
unqualified and disabled. Native authenticated capture/publisher and terminal
adapters remain implementation dependencies. The complete source-linkage gate
now has an actual replayable Git-object verifier with11 passing local controls;
final source/runtime artifacts and strict packaged gate remain outstanding.

Increment7 committed `5388c7adc138e1ea8ef88db36e4fba61812e6760`;
`integration/COMMIT-07.json` records actor and26paths. Its exact detached source
passed165 tests in13 named modules with clean trackedtree. This scoped gate
does not cover two separately discovered producer input-bound counterexamples
now being repaired or finalpackage qualification.

Actual read-only GitHub reassessment found two baseline289 workflow failures
with zerojobs. Public annotation proves job-level `runner.temp` was invalid.
The local repair moves CI_ROOT to a guarded runner step; ninelocaltests,
unchanged checksum-pinned actionlint and seven independent shellcontrols pass.
Original remote failures and beforebytes remain. Source/handoffbranches were
observed unprotected; connector permissions do not grant control-administration
authorization. FinalhostedCIqualification remains open.

Increment8 prepares the 0.9.0 engineering candidate. Exact description-recovery
state-write interruption now has actual protected native evidence: one failed
state-write operation, separately signed original lease release, native no-change
plan, fresh identity and sealed readback. The original operation remains
`service_state_converged_execution_unknown`, with one dispatch and its original
failure preserved. Native15/observer27/recovery21 and independent30/27 checks
are overlapping scopes, never an aggregate. The exact79 runtime files and eight
harnesses are linked in `worker-provider/NATIVE-SERVICE-EVIDENCE-INDEX-04.json`.

Already-unlocked partial recovery now uses its own sealed read-only attestation
and explicitly discriminated successor approval v2. A constructed unlocked
premise is labeled; it does not claim a native fault reproduced that premise.
Secondary failure-recording errors no longer mask the original failure, including
a post-commit uncertainty. Ordinary execution approval remains v1. Producer
path-depth and literal-link byte-bound counterexamples are repaired and retained.

Current parent is5388c7adc138e1ea8ef88db36e4fba61812e6760. Resume command:
`git status --short`; then read the latest `integration/COMMIT-*.json`, this
checkpoint and `docs/CONTINUATION-R4-LEDGER.json`. Next: finish reviewed native
Windows capture/publication, shared terminal/context and inactive scheduled-job
integration, qualify exact final packages and verify suitable delivery. Windows
local components do not imply native-host qualification. Laboratory completion
is still incomplete, platform qualification blocked, production approval absent.

Increment8 committedb1ea9331de53228c0a0220928d8c0c38471b2a63 (24paths).
Exact detached source passed98tests in9named modules,36.180seconds, clean
trackedtree; receipt `integration/checkpoint8-changed-01/RECEIPT.json`.
All300 recorded top-level receipt references matched50unique retained files
at ledger integrity check01. This is scoped integrity, not all nested evidence.

Increment9 integrates inactive Windows capture/publication and the shared
console/context workspace. Source-label mutation and alternate POSIX relocation
of native-bound capture both have retained failing-before/passing-after evidence.
Native observation source receipt binds155local methods and14independent controls
with explicit overlapping scope; actual Windows qualifier remainsBLOCKED0.
Console uses existing Workspace/parser/engine, explicit Ctrl+Enter submission,
append-only navigation context and pre-dispatch rejection of unsupported native
commands. Real Windows/IME/mintty remain unqualified. Scheduler and native views
completion are still staged implementation dependencies.

Reconciliation discovered durable protected-service import/adoption is a real
local code gap: the native import evidence used a preparation harness. The
legacy provider prepare route is still network-denied. A separately approved
state mutation/recovery contract is now being designed; do not hand this back
as a credentials-only blocker or exclude adoption from the requirement.
Doctor accurately reports this distinction and inactive Windows components
without enabling any ordinary unsupported host route. Actual10doctor assertions
and17CLI/host regressions pass; scopes overlap other suites.

The CI validator preparation now recovers exact existing public package/library
pins without installation or repinning. Public download and seven actual
preparation controls pass; hosted CI remains unqualified. Current managed
environment metadata has no capabilities, identities, secrets or runtime
variables; no values were requested. Source changes remain on the dedicated
continuation branch. Read latest commit receipt and this ledger before resuming.

The exact integrated console increment passed 45 scoped tests in 8.284 seconds,
including 16 existing Linux PTY/no-TTY cases; seven independent recorded-Win32
application checks overlap that scope. CI preparation independently passed ten
controls, and the actual YAML step plus existing vault/CI consumers passed 17
scoped cases. Inventory 23 explicitly admits 3,248 source and 233 runtime files.
New transfer helpers are still under review and excluded from this checkpoint.
Scheduler review found a shadowed duplicate renderer and erroneous success after
cleanup failure; both failing candidates remain preserved, with repairs staged.
No native scheduler activation, real Windows qualification or production claim.

Increment9 committed `f58bbadf9672cc0d52b5997366ac0611ead76634`. The exact
detached source passed162 changed-scope tests in13modules, with a clean tracked
tree. All3248 selected source files independently matched raw Git commit/tree/
blob objects in `source-linkage/CHECKPOINT9-FULL-LINKAGE-01.json`. These results
do not qualify the later changes or final packages.

Increment10 integrates the separately reviewed native observation job, existing
Generic Credential reader and disabled Task Scheduler material. No credential
is provisioned or task registered. Scope is local SQLite and recorded Win32;
actual Windows, Task Scheduler and authenticated Graph remain blocked. The
57-test owner scope overlaps independent compound-failure, retention and
measurement-cancellation controls. Every prior failed candidate remains in
`windows-observer-scheduler-staging/` and `independent/windows-scheduler-*`.

Exact ordered eight-layer download and offline/new-branch Git transfer tools
are now admitted. Independent tiny reconstruction and actual owned-local-Git
controls prove the expected-absent race repair. They do not establish public
R4 availability or fresh complete-corpus reconstruction. Source inventory25
contains3258files/runtime241 before the later views and shutdown admissions.

Ordinary service shutdown review reproduced five compound counterexamples:
four errors and one failure because cleanup or outcome recording could hide
the first host failure/interruption. The repair revokes the permit before
cleanup, preserves primary/secondary causes and cancellation, retains writer
ownership, and records pre/postcommit uncertainty without replay. The five
original oracles now pass;36 changed/adjacent service and native Docker/TLS/
readback tests pass. Independent review is still pending in this working note.
Before source and all logs remain in `worker-service/shutdown-*`.

Protected state-only adoption now has an approved bounded architecture and
three staged implementation lanes. Empty selected state does not establish
global ownership; complete declared-scope evidence and separately signed sole
writer intent are required. Native import lock metadata `OperationTypeInvalid`
is admissible only in the new exact adoption contract. Ordinary saved-plan
apply must remain unchanged. Current native preparation evidence remains a
harness scope until the durable product entrypoint and recovery pass.

Resume from the latest `integration/COMMIT-*.json`; run `git status --short`
in the dedicated continuation branch, read this checkpoint and the ledger,
then complete independent review/integration before signing new native runs.
Do not mutate runtime source during a signed whole-inventory qualification.
Final packages, public readback, platform gates and accountable production
approval remain outstanding; no background completion is implied.

Increment10 independent service review now passes12 controls on exact
`worker_service.py`636d6cd88004a164dce03bd7e3b3b680e2ff0b52e4bfbec3f62ad9cb6154887f.
The same source passed36 changed/adjacent tests. A lost duplicate receipt file
retains its known authoritative DB outcome with an explicit archive-failure
event; an uncertain DB acknowledgement is separately recorded and cannot replay.
The initial counterexamples and independent evaluator setup errors remain.

The native four-view adapter is integrated through the same text/workspace
engine:48 selected repository tests and14 independent input/state controls
pass with explicit overlapping scope. Raw targeting/unsupported IDs, distinct
drift baselines and unchanged SQLite bytes are independently checked. Native
source revalidation is still a separate staged implementation; unsupported
worker journals are never opened or promoted into verified baselines.

Increment10 committed `b7eae48ed943e14fa2aac2e17d2c337999aa671a`; its
exact detached four new changed modules passed82 tests, with clean tracked
source. Receipt `integration/checkpoint10-changed-01/RECEIPT.json` preserves
the exact log and scope. Discovery of1912 unique IDs executed no tests and
is not a release result. Historical1242/1141 results remain separate.

Increment11 integrates the reviewed native current-source reader through
the existing literal resolver and shared terminal.73 selected tests and12
independent controls pass with overlapping local/recorded-Win32 scopes.
Current source bytes/resolved values remain separate from the recorded Git
revision assertion. Native Windows, Git authentication and native source
intent import/reviewed editing are not established by this reader.

Relocatable qualification prerequisites now accept only the same fixed
Docker/ToFu/relay bytes, including exact reproducible relay source. Missing
or changed tools fail rather than skip. Inventory29 contains3271 source
and250 runtime files; no final archive has been produced.

Independent signed-adoption integration reproduced an omitted state-contract
mapping before host dispatch. One approval consumption and all reservations
were retained; the corrected mapping passes the unchanged eight controls.
Both before and after are preserved. Final intended-writer/history binding,
actual native adoption/change and fresh-process recovery are still staged.

Resume from `integration/COMMIT-11.json` after this checkpoint: inspect
`git status --short`, read this ledger and the frozen proposed integrations,
then finish review before whole-runtime signing. Do not rerun historical
full suites. No platform or organizational production approval is claimed.

Increment11 committed `8fb914a36651b0bd79e3e4f2d342294613682685`; all3271
selected files match independently rehashed Git objects. The91-row ledger
passes487 top-level receipt references across84 unique files; no tests rerun.

Increment12 integrates distinct signed protected state-only adoption, shared
writer reservations/nonce authority, exact native import/first-plan controls,
frozen signed-approval transcripts and durable adoption links/history. Atomic
transcript failure prevents dispatch.76 integrated interface checks pass with
injected adoption host; separate110 unique adjacent methods include19 actual
ordinary native Docker/TLS service routes. The original inaccurate76 scope
phrase is retained with `integrated-02/SCOPE-CORRECTION-01.json`. Counts are
scoped and overlapping, never a new combined total. Native adoption itself is
the next gate and is not yet claimed by these interface checks.

Native repository intent import and immutable source proposal are integrated.
Their90-test candidate scope and12 independent controls retain recorded-Win32
limits. Source remains untouched by proposal; full byte diff, shared impacts
and fresh-plan requirements remain explicit. The native source writer/recovery
is separately staged. Local checkout identity and the approved logical worker
repository URL need an explicit reviewed binding; a Git remote is not proof.

Adoption navigation repairs preserve legacy help and read-only operation context
across review/execution tabs and reopening. Independent14 actualLinuxPTY checks
on a disposable prepared journal pass after preserved help/context/back failures;
17 presentation methods also pass. These do not qualify nativeWindows or a
successful native journal/final package. Those replays remain required.

Two authorized agents concurrently admitted the same source paths. The collided
inventory/builder bytes and observed check30 receipt are preserved under
`integration/admission-collision-01/`. Redundant runtime entries/empty comment
were repaired without losing source selection. Both wrote check30; the first
output's exact bytes were not independently retained. Check31 is a new scoped
validation, not restoration of that result. Root now exclusively owns inventory
admissions. This event does not close any historical provenance finding.

Resume from `integration/COMMIT-12.json`: inspect `git status --short`, read the
ledger and frozen source pins, then execute native adoption/change and distinct
interruption cases without runtime edits during signing. Portable signed worker
evidence, native source writing, source/execution binding and adoption recovery
remain staged dependencies. Final packages, required external routes and
accountable organizational approval remain incomplete.

Increment13 preserves actual checkpoint12 native adoption, first no-change plan,
same-authority source correction/exact saved-plan application, independent
readback and second no-change plan. Index02 records each exact operation and
source snapshot. Independent raw19 and LinuxPTY15 scopes overlap the producer
and literal assertions; no combined count is claimed. All3288 selected source
files matched checkpoint12 raw Git objects; inventory32 validates selection.

Three independently approved native interruption operations retain their own
once rows, source inventories, leases and unknown outcomes. The acquisition
harness initially expected exit0, while the application correctly returned3 for
unknown. Its failed evaluation remains; read-only reevaluation corrected only
the oracle and did not rerun import. Fault roots under /tmp are mandatory full
R4 evidence inputs. No adoption lease was released or import replayed.

Recovery, source-intent execution binding, native guarded source editing and
portable signed evidence remain staged. Root review and independent controls
found receipt-envelope, cleanup, publisher-rotation, synthetic/live contradiction
and interrupted source-edit defects; before records remain, and only precisely
rechecked repairs may be integrated. External gates are not used to defer these
local requirements. The source-intent watchdog also needs thread-safe verified
source rechecks; the initial main-thread-only Git failure is retained.

Resume from integration/COMMIT-13.json and worker-provider/
NATIVE-ADOPTION-EVIDENCE-INDEX-02.json: inspect git status, integrate only reviewed
source pins, then freeze new runtime before fresh recovery approvals. Retain
original operation authorities and history. Do not rerun historical full suites.
Final packages, native Windows/real service routes, AppSec and accountable
production approval remain incomplete.

Increment14 integrates the reviewed initial-import recovery/projection/typed
baseline disposition and separately signed Plan-only verification bridge. It
also integrates the inactive native source editor with exact identity/metadata
and ancillary-input rechecks, retained partial journals and explicit recovery.
All files are admitted deliberately into source/runtime selection.

The native source119 changed/adjacent methods and independent16/6/7 scopes
pass with recorded Win32 boundaries. Actual native Windows is BLOCKED0.
Recovery23 component and31 bridge/presentation scopes pass; the23 receipt
explicitly lacks a separately configured raw log. Two read-only native fault
preflights classify exact original baseline versus committed successor. No
recovery lease release or native recovery Plan has yet occurred.

This is a preserved failing candidate, not a release: B-NOOP-01 records
independent no-op JSON mutants (wrong ID, unequal values, wrong filter) accepted
by the minimal parser. Initial and recovery paths need one strict value/artifact
repair. The actual binary remained unchanged; no full capability bypass is
claimed. Original passing native bytes and failed controls remain. New signing
is held until repair, while source-intent, portable evidence and Plan-phase
recovery work continues independently.

Resume: read integration/COMMIT-14.json, git status --short, the92-row ledger and
worker-service/plan-evidence-staging proposals. Integrate only reviewed repair
pins, then freeze a new source revision before recovering the original fault
authorities. Do not replay import. Finish remaining local integration and exact
package/delivery gates; all platform/organizational approvals remain separate.

Increment15 integrates the exact local source-authoring/worker-v2 binding, shared
post-host native no-change artifact capture and full typed content validation,
and explicit-root evidence snapshot preparation. Source/runtime inventory is
root-owned; new files are deliberately admitted. COMMIT-15.json records the
exact commit and tree. The current contract link now names its actual existing
STRICT-CONTINUATION-CONTRACT-R4.md path; earlier ledger versions remain in Git.

Independent no-op mutants exposed boolean/integer/float equivalence; root review
also found required=true versus1, absent-versus-null and a regular-to-FIFO read
race. Exact before attempts are retained. Repaired inserted38 checks pass, with
separate overlapping independent content/archive/source review evidence. This
establishes a local repair, not a new native caller or live platform pass. The
next freeze must exercise initial and recovery Plans with these exact bytes.

Portable evidence reopen after a newer sequence also failed independent signed
CLI controls. Its staged repair passes the unchanged five assertions; integration
and adoption-domain/native-store restore qualification remain pending. These
failures are not erased by subsequent passes. Snapshot preparation has fourteen
local controls; full-corpus copying, independent review, final public suitability
and archive reconstruction have not occurred. Unresolved temporary inputs and
explicit IPC/capsule mappings remain visible.

Resume from integration/COMMIT-15.json and git status --short. Finish reviewed
common Plan-phase integration, freeze runtime, then recover the retained native
fault authorities with new exact approvals and no import replay. Complete the
same-authority v2 source journey and portable evidence path; then qualify exact
final packages and delivery. Historical1242/1141 totals are not repeated or added.

Increment16 adds the six selfcontained source-intent regression methods and
retains final independent strict-plan and snapshot preparation evidence. Its
product runtime is byte-identical to checkpoint15; only test/inventory/docs
change. COMMIT-16.json records exact source and dirty-tree observation. Native
original-import recovery and same-authority source-v2 maintenance may now be
qualified under a coordinated runtime freeze. Common stopped-Plan extensions
and portable receipt integration remain staged, with no shared runtime edits
during signed operations. New initial Plan cancellation creates a distinct
authority once; it must never replay an old import. No final package/global
laboratory/platform/production completion is implied.

Increment17 preserves the C16 native recovery evidence before integrating the
next dependency wave. Three original interrupted imports received separate
exact lease-recovery approvals; concurrency, receipt-recording interruption and
lost response preserve once-only release and unknown histories. The committed
import subsequently passed a new separately approved native no-change Plan and
readback. These local TLS fixture results do not qualify real Azure or Intune.

The native source-v2 attempt failed before approval because the actual overlay
inode exceeded JSON's safe integer range. Binding/storage schema2 now preserves
uint64 identity as canonical decimal strings; the global numeric gate remains
unchanged. Eight inserted checks and six independent controls qualify that local
repair. The exact retained proposal is the next native continuation input.

Stopped initial and recovery Plan phases now have distinct approval/release
contracts and bounded immutable successor ancestry. The real typed-phase
composition first rejected the complete broker/host/lease fact union; the
stronger two-site comparison repair retains all eight additional pins. No
previous import or failed Plan may be replayed to close this gate.

Portable signed worker history is integrated with current-trust revalidation,
publisher-wide ordering, exact raw archives and explicit synthetic evidence.
The actual retained v1 native recovery Plan was exported, signed, received and
reopened through the product CLI. State-only recovery remains separate from a
Graph deployment baseline. Windows-shaped tests do not establish native Windows.

Nine-layer restoration preserves separate complete epoch and attributed external
evidence supplements. Final archives and publication readback are pending; the
current filesystem cannot hold a new simultaneous full-corpus reconstruction.
The original archives and historical anomalies remain unchanged.

Execution transport failed intermittently before process creation during this
increment. Failed tool calls were not recorded as product failures or passes;
pending writes were checked before retry. COMMIT-17.json identifies the final
committed files and any remaining working-tree changes. Resume with:

    cd /workspace/intune-continuation/work/projects/intune
    git status --short
    git log -1 --format='%H %s'
    /workspace/intune-runtime/bin/python -B scripts/build-release.py --check-only

Then follow EXECUTION-SEQUENCE-R4.md: qualify the retained source-v2 proposal and
initial-Plan/new-Plan interruption recovery chain under an exact runtime freeze,
finish native signed-history linkage, and qualify the exact final packages.
The historical 1141/1242 suites remain separate. Laboratory completion, real
platform qualification and accountable production approval are not established.

Increment18 integrates the closed portable Plan-v2 decoder after two retained
counterexamples. A version2 predecessor now requires its exact ancestry edge
and a coherent initial-verification or version1 terminal record. Every retained
predecessor approval uses its own signature domain. The current original status
may advance after reconciliation while the exact historical stopped phase row,
approval, dispatch and outcome stay bound. A successful new history read does
not rewrite the original execution-unknown result.

Independent actual signed CLI/SQLite controls, a separate true bad-signature
control, and original native-v1 Plan/export raw-byte review are retained with
their distinct overlapping scopes. COMMIT-18.json is the exact native signing
freeze. No runtime edits are allowed during the following coordinated runs:
retained source-v2 proposal with new approval; exact stopped initial-Plan release;
new Plan1 deliberately interrupted after acquisition; its separate exact release;
new Plan2 no-change output/readback/reconciliation. Old imports and Plans are
never requeued. The prepared PTY checker inspects the quiet completed history
without issuing mutation commands. Final package and external gates remain.

Increment19 preserves C18 source-bound native maintenance: exact retained saved
proposal, new approval, source/lock negative controls, actual apply, independent
readback, state14 to15, native no-change Plan and persistent views. Producer25,
independent raw23 and signed-export16/raw9 are separate overlapping scopes.
No import or proposal was replayed; unsupported raw ID37 acceptance remains
explicit, and none of this establishes real tenant or endpoint evidence.

The retained initial Plan lease and a newly interrupted Plan1 lease each received
a distinct exact recovery approval. The new Plan2 then FAILED during concurrent
watchdog/broker checks with service_store_unavailable. Its approval is consumed,
outcome unknown, original scopes retained and host removed. Exact journals show
one provider-instance GET, zero backend/lease attempts and unchanged state13.
There is no lease to release and the failed Plan will never be replayed.

Root cause: prior-Plan selection reconstructed ServicePolicy and opened a schema
write transaction from repeated read checks. A genuine held-reader/writer
counterexample fails before the private read-only opener repair and passes after;
all exact root/reference/manifest/registered-row checks remain. The repair is
integrated: 34 scoped methods (31 overlapping and three added) pass against the
inserted bytes; five independent assertions preserve the before/after result.
Timeouts and approval gates were not weakened. Distinct sealed no-acquisition observation,
versioned successor approval and corresponding portable history remain staged.

COMMIT-19.json records the current source and working tree. Resume with the
checkpoint18 Plan2 failure receipt and EXECUTION-SEQUENCE-R4.md; finish the bounded
no-acquisition assessment, then approve a NEW successor under frozen repaired
source. No current native convergence or final-package pass is claimed. Baseline
evidence and the earlier valid C18 journeys remain preserved at their exact bytes.

Increment20 integrates the distinct stopped-Plan no-acquisition assessment.
Only a bound stopped phase with zero backend, lease and state-write attempts is
admitted. Fresh typed backend and Graph reads, exact original state, an absent
host and unchanged consumed rows/ownership are required. The assessment creates
an append-only observation; it cannot release a lease or authorize execution.
Inserted14 parser/guard methods and independent19 assertions/19 overlapping
negative controls preserve their precise scopes. The actual Plan2 stays failed
and unknown. New /3 approval/successor history and a focused public constructor
read-path repair are staged; no new native Plan has been dispatched.

Two historical C18 lease releases now have separate independent raw17 evidence.
An interim preservation capsule includes407 proxy namespaces and42 explicitly
omitted socket nodes as metadata; originals remain unchanged. A staged history
qualification helper changed without attributable author evidence. Both versions
and the evaluator failure are retained; the unexplained version is not admitted.
Neither finding resolves older provenance anomalies. A ledger-update helper
failed on an absent optional receipt list, before writing; its source/failure and
unchanged ledger hash are preserved in integration/ledger20-attempt01.

Read integration/COMMIT-20.json for exact source/working-tree identity. Resume:

    cd /workspace/intune-continuation/work/projects/intune
    git status --short
    git log -1 --format='%H %s'
    /workspace/intune-runtime/bin/python -B scripts/build-release.py --check-only

Then finish the bounded staged repairs and their independent controls, commit a
new native freeze, and execute a NEW approved successor through the actual
worker. Do not replay failed Plan2 or call the no-acquisition observation a
release. Exact final packaging, platform qualification and accountable approval
remain separate unfinished gates.

Increment21 integrates the separately signed Plan /3 successor, closed portable
history and read-only public service/adoption/Plan constructors. Distinct
observation edges coexist with the unchanged historical release edges. Exact
raw anchor bytes, original phase/ownership, fresh state/identity and prior
consumed operations remain required. Actual signature-domain and cross-table
negative controls reject wrong proofs without a native dispatch.

Public status/attach no longer initializes schema. Actual subprocess readers
see committed values while another connection holds uncommitted writes. An
exact existing-schema check rejects altered conflict/collation/CHECK semantics;
close failures preserve the primary cause and secondary interruptions. All
failing-before cases, partial insertion/evaluator failures and repairs remain
retained. Preparation/migration remains an explicit separate API with backup
and quiescence requirements; no timeout or approval gate was relaxed.

Portable history now keeps pre-Plan and refreshed identity-binding hashes
distinct when metadata changes ETag, while enforcing the same exact principal,
backend, state content/revision, storage and linked evidence. The former honest
rebind rejection and independent signed after controls are preserved. The new
history helper is explicitly derived from the known baseline; the unexplained
staged edit remains an unresolved provenance finding.

The scoped product gates are48 successor methods,22 shared public-reader methods,
6 Plan-reader methods and37 portable-history methods. They overlap prior and
independent scopes and are not a combined suite total. COMMIT-21.json records
the exact native signing freeze. No runtime changes are permitted during the
NEW Plan3 run, subsequent signed export and quiet mixed-history PTY inspection.
The consumed failed Plan2 is never replayed; no native convergence is claimed
until the new operation and independent readback actually complete.

Resume using the exact commit receipt and EXECUTION-SEQUENCE-R4.md, then the
prepared final-package drivers. Preserve the historical1141/1242 results and
all unresolved platform, provider, scheduler, provenance and approval gates.

Increment22 records the C21 native Plan3 result without changing runtime bytes.
New operation ccc821ee-32d2-4829-b8c6-511acb744487 completed native no-change
verification with exact state13 and independent Graph/settings/assignment readback.
Its /3 approval and observation edge are distinct from the earlier lease releases.
The original import and failed Plans remain consumed/unknown in history; no Plan
was replayed and no nonexistent Plan2 lease was released. Host/fixture cleanup
completed. Producer24, independent raw23, signed application history14 and
quiet Linux PTY30 have overlapping scopes and must not be added.

The real terminal sequence reviewed all /2,/2,/3 operations, switched tabs,
opened original/history, went back and reopened context with restored terminal
state. Independent authority/file checks stayed unchanged. Signed history keeps
pre-Plan and refreshed binding identities explicit; it does not assert a verified
Graph deployment baseline or organizational actor authority.

Current source is ready for final package qualification, not production release.
Read integration/COMMIT-22.json for exact commit and inventory, then execute:

    /workspace/intune-runtime/bin/python -B /tmp/intune-r4-final-package.py --commit FULL_COMMIT_FROM_RECEIPT --output NEW_PACKAGE_DIRECTORY

The driver safely extracts both exact archives, verifies all source against raw
Git objects and rebuilds byte-identically from extracted source. Before the final
strict suite, the gate must compare extraction membership/bytes to the exact ZIP;
unchanged before/after files alone do not establish package identity. Final native
journeys use the reviewed closed helper profile and complete extracted source.
The runtime-only archive receives its own actual text/PTY/connected checks and
full byte linkage to that source; do not mislabel this as runtime-only native
execution. Preserve all source qualification failures and historical1141/1242
evidence. Platform qualification and accountable approval remain blocked.

Increment23 preserves the FAILED C22 required exact-source gate. The source ZIP
is17,932,603 bytes/a97968ccc4a86f4549c7ab31f7f0467692609bb2e1177a66a7754e8433689b87;
the runtime ZIP is1,499,635 bytes/48a3cf1d2e4a12a5d960bda3b193b565a014bcc4c463ee7ff3543ea5671466f7.
Raw Git linkage, independent ZIP membership/bytes and reproducible builds passed.
The runtime text/PTY/connected journey passed its exact scope; neither result
changes the source-suite failure. All package/extraction bytes stayed unchanged.

The required suite planned2300 methods, ran2213, passed2086, and recorded5 failures
and130 errors, with zero skips. Eight class-setup errors account for87 methods
not run; they are neither passes nor skips.126 errors share the deleted/unbound
native-library mapping guard. A real wrong-library approval negative leaves an
irreversible dlopen mapping in the shared test interpreter; the subsequent guard
correctly rejects it. Repair the offending test's process isolation, not the
security gate. Release-transfer fixtures expose five new layers against a
four-layer stager and an inherited TestCase.fail override. One native source-edit
fixture expects a missing result key. Focused before/after repairs are pending.

Read /tmp/intune-r4-final-strict-01/RECEIPT.json and its complete test-log, then
integration/COMMIT-23.json for this failure checkpoint. No complete suite retry
is justified by a changed count alone: admit the concrete repairs, qualify
focused ordered cohorts independently, commit/build a new exact candidate, then
run its required gate. Never overwrite C22 outputs. The closed native profile
also needs the existing ordinary partial, committed-state and reverse-description
fault routes before new artifact qualification is complete. Performance is only
preregistered, not timed. Complete delivery must include raw Intune Git history
and unselected bytecode evidence; do not call a selected source ZIP full recovery.

Increment24 integrates the three demonstrated C22 strict repairs. The irreversible
wrong-native-library negative now runs in a child and still asserts deleted-map
rejection. The parent subsequently binds a real service manifest; the runtime
identity guard is unchanged. The transfer stager now admits exactly five new
layers, including external evidence, and retains exact nine-layer recovery. Its
assertion helper no longer masks unittest failures. Native Windows inspection
now preserves the pending local-edit operation and manual status guidance after
a lost rename acknowledgement, while import remains blocked and outcome unknown.

Focused integrated scopes20/39/26 and independent7/18/15 overlap and are never
summed. All prior C22 failures, setup/evaluator failures and negative controls
remain unchanged. Native Windows remains unqualified. Current runtime changed
only in pending-edit presentation; new source/runtime artifacts must be built.

Resume from integration/COMMIT-24.json and the exact insertion/scoped receipts,
then build into a NEW package directory with /tmp/intune-r4-final-package.py.
Run the repaired exact-ZIP-admission /tmp/intune-r4-final-strict.py only against
that new package receipt. The failed C22 directory must never be reused or edited.
After a passing required gate, run actual runtime and the full closed native
profile including ordinary partial/committed-state/reverse-description faults.
Performance preparation for C22 remains untimed historical preparation; rebind
the new candidate before claiming measurements. Full Git/unselected-bytecode
preservation and the separately blocked external gates remain required.

Increment25 preserves C24 exact source/runtime integrity, reproducible builds,
actual CLI/PTY/connected journeys and the required2304/2304 strict result with
zero failures/errors/skips and unchanged extracted source/archive. These are
local scopes and counts overlap. C22 failures remain immutable.

Actual doctor output exposed stale adoption capability labels. The report-only
repair now says durable signed state-only import is implemented, names required
host/controller/review/readback conditions, and explicitly keeps live, platform
and organizational production qualification false. The terminal gains no import
dispatch authority. Before3/2fail, integrated14PASS and independent12PASS are
preserved separately. One new test file was explicitly admitted to source inventory.

The expanded closed27-helper native qualifier is admitted after independent
type/duplicate-key/prior/planned-value/targeting/cleanup counterexamples and their
repairs. Static export is preparation only. Use a NEW final profile bound to C25
complete extracted source; prepare the ordinary seed immediately after fresh
adoption and before maintenance changes that fixture. Never use active-checkout
fallback or replay old consumed unknown operations.

Resume from integration/COMMIT-25.json:
  /workspace/intune-runtime/bin/python -B /tmp/intune-r4-final-package.py --commit COMMIT_FROM_RECEIPT --output /tmp/intune-r4-final-packages-03
  /workspace/intune-runtime/bin/python -B /tmp/intune-r4-final-strict.py --package-receipt /tmp/intune-r4-final-packages-03/PACKAGE-RECEIPT.json --output /tmp/intune-r4-final-strict-03
After the required gate is quiet and passes, finish actual runtime/native/fault/
signed-history/PTY journeys, preregistered quiet-window performance and complete
layered archive/readback delivery. Laboratory completion is not yet established;
native Windows, real service/backend/CI/device, AppSec and organizational approval
remain separate gates with the existing exact external procedures.
