package graphBetaSettingsCatalogConfigurationPolicyJson

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"github.com/deploymenttheory/terraform-provider-microsoft365/internal/constants"
	"github.com/deploymenttheory/terraform-provider-microsoft365/internal/services/common/crud"
	customrequest "github.com/deploymenttheory/terraform-provider-microsoft365/internal/services/common/custom_requests"
	errors "github.com/deploymenttheory/terraform-provider-microsoft365/internal/services/common/errors/kiota"
	identitymodels "github.com/deploymenttheory/terraform-provider-microsoft365/internal/services/common/shared_models/graph_beta"
	sharedmodels "github.com/deploymenttheory/terraform-provider-microsoft365/internal/services/common/shared_models/graph_beta/device_management"
	sharedstater "github.com/deploymenttheory/terraform-provider-microsoft365/internal/services/common/state/graph_beta/device_management"
	"github.com/hashicorp/terraform-plugin-framework/path"
	"github.com/hashicorp/terraform-plugin-framework/resource"
	"github.com/hashicorp/terraform-plugin-framework/types"
	"github.com/hashicorp/terraform-plugin-log/tflog"
	"github.com/microsoftgraph/msgraph-beta-sdk-go/models"
)

// Create handles the Create operation for Settings Catalog resources.
//
//   - Retrieves the planned configuration from the create request
//   - Constructs the resource request body from the plan
//   - Sends POST request to create the base resource and settings
//   - Captures the new resource ID from the response
//   - Persists only the known identity before a separate assignment request
//   - Sends assignment configuration once if specified
//   - Retains a sparse recovery anchor on assignment or readback failure
//   - Calls Read operation to fetch the latest state from the API with retry
//   - Updates the final state with the fresh data from the API
//
// The function ensures that both the settings catalog profile and its assignments
// (if specified) are created properly. The settings must be defined during creation
// as they are required for a successful deployment, while assignments are optional.
func (r *SettingsCatalogJsonResource) Create(ctx context.Context, req resource.CreateRequest, resp *resource.CreateResponse) {
	var object sharedmodels.SettingsCatalogJsonResourceModel

	tflog.Debug(ctx, fmt.Sprintf("Starting creation of resource: %s", ResourceName))

	resp.Diagnostics.Append(req.Plan.Get(ctx, &object)...)
	if resp.Diagnostics.HasError() {
		return
	}

	ctx, cancel := crud.HandleTimeout(ctx, object.Timeouts.Create, CreateTimeout*time.Second, &resp.Diagnostics)
	if cancel == nil {
		return
	}
	defer cancel()

	requestBody, err := constructResource(ctx, &object)
	if err != nil {
		resp.Diagnostics.AddError(
			"Error constructing resource for Create Method",
			fmt.Sprintf("Could not construct resource: %s: %s", ResourceName, err.Error()),
		)
		return
	}

	requestAssignment, err := constructAssignment(ctx, &object)
	if err != nil {
		resp.Diagnostics.AddError(
			"Error constructing assignment for Create Method",
			fmt.Sprintf("Could not construct assignment: %s: %s", ResourceName, err.Error()),
		)
		return
	}

	baseResource, err := r.client.
		DeviceManagement().
		ConfigurationPolicies().
		Post(ctx, requestBody, nil)

	if err != nil {
		errors.HandleKiotaGraphError(ctx, err, resp, constants.TfOperationCreate, r.WritePermissions)
		return
	}

	if baseResource == nil || baseResource.GetId() == nil || strings.TrimSpace(*baseResource.GetId()) == "" {
		resp.Diagnostics.AddError("Create outcome requires reconciliation", "The create response did not contain a usable resource identity. Do not retry creation without checking for a remotely created policy.")
		return
	}
	object.ID = types.StringValue(*baseResource.GetId())
	// Retain the known remote identity before the separate assignment effect.
	// Planned remote attributes are not observations and must not enter partial
	// state when assignment or readback fails.
	resp.Diagnostics.Append(resp.State.SetAttribute(ctx, path.Root("id"), object.ID)...)
	resp.Diagnostics.Append(resp.State.SetAttribute(ctx, path.Root("timeouts"), object.Timeouts)...)
	if resp.Identity != nil {
		resp.Diagnostics.Append(resp.Identity.Set(ctx, identitymodels.ResourceIdentity{ID: object.ID.ValueString()})...)
	}
	if resp.Diagnostics.HasError() {
		return
	}

	if requestAssignment != nil {
		_, err = r.client.
			DeviceManagement().
			ConfigurationPolicies().
			ByDeviceManagementConfigurationPolicyId(object.ID.ValueString()).
			Assign().
			Post(ctx, requestAssignment, nil)

	}

	if err != nil {
		errors.HandleKiotaGraphError(ctx, err, resp, constants.TfOperationCreate, r.WritePermissions)
		return
	}

	readReq := resource.ReadRequest{State: resp.State, ProviderMeta: req.ProviderMeta}
	// The read request carries only management intent for an empty assignment
	// collection. It is separate from the response's sparse recovery anchor.
	// Strict Read replaces it with observed targets before successful state commit.
	if !object.Assignments.IsNull() {
		resp.Diagnostics.Append(readReq.State.SetAttribute(ctx, path.Root("assignments"), types.SetValueMust(object.Assignments.ElementType(ctx), nil))...)
		if resp.Diagnostics.HasError() {
			return
		}
	}
	stateContainer := &crud.CreateResponseContainer{CreateResponse: resp}
	opts := crud.DefaultReadWithRetryOptions()
	opts.Operation = constants.TfOperationCreate
	opts.ResourceTypeName = ResourceName

	err = crud.ReadWithRetry(ctx, r.Read, readReq, stateContainer, opts)
	if err != nil {
		resp.Diagnostics.AddError(
			"Error reading resource state after create",
			fmt.Sprintf("Could not read resource state: %s: %s", ResourceName, err.Error()),
		)
		return
	}

	tflog.Debug(ctx, fmt.Sprintf("Finished Create Method: %s", ResourceName))
}

// Read handles the Read operation for Settings Catalog resources.
//
//   - Retrieves the current state from the read request
//   - Gets the base resource details from the API
//   - Maps the base resource details to Terraform state
//   - Gets the settings configuration from the API
//   - Maps the settings configuration to Terraform state
//   - Gets the assignments configuration from the API
//   - Maps the assignments configuration to Terraform state
//
// The function ensures that all components (base resource, settings, and assignments)
// are properly read and mapped into the Terraform state, providing a complete view
// of the resource's current configuration on the server.
func (r *SettingsCatalogJsonResource) Read(ctx context.Context, req resource.ReadRequest, resp *resource.ReadResponse) {
	var object sharedmodels.SettingsCatalogJsonResourceModel
	var baseResource models.DeviceManagementConfigurationPolicyable
	var identity identitymodels.ResourceIdentity

	tflog.Debug(ctx, fmt.Sprintf("Starting Read method for: %s", ResourceName))

	operation := constants.TfOperationRead
	if ctxOp := ctx.Value("retry_operation"); ctxOp != nil {
		if opStr, ok := ctxOp.(string); ok {
			operation = opStr
		}
	}

	resp.Diagnostics.Append(req.State.Get(ctx, &object)...)
	if resp.Diagnostics.HasError() {
		return
	}

	tflog.Debug(ctx, fmt.Sprintf("Reading %s with ID: %s", ResourceName, object.ID.ValueString()))

	ctx, cancel := crud.HandleTimeout(ctx, object.Timeouts.Read, ReadTimeout*time.Second, &resp.Diagnostics)
	if cancel == nil {
		return
	}
	defer cancel()

	identity.ID = object.ID.ValueString()

	if resp.Identity != nil {
		resp.Diagnostics.Append(resp.Identity.Set(ctx, identity)...)
		if resp.Diagnostics.HasError() {
			return
		}
	}

	baseResource, err := r.client.
		DeviceManagement().
		ConfigurationPolicies().
		ByDeviceManagementConfigurationPolicyId(object.ID.ValueString()).
		Get(ctx, nil)

	if err != nil {
		if errors.GraphError(ctx, err).StatusCode == 400 {
			resp.Diagnostics.AddError("Incomplete policy observation", "A bad-request response does not prove the policy was deleted; existing state was retained.")
			return
		}
		errors.HandleKiotaGraphError(ctx, err, resp, operation, r.ReadPermissions)
		return
	}

	if baseResource == nil || baseResource.GetId() == nil || *baseResource.GetId() != object.ID.ValueString() {
		resp.Diagnostics.AddError("Incomplete Policy Observation", "The policy response must contain the requested immutable identity; no state was updated.")
		return
	}
	if baseResource.GetName() == nil || baseResource.GetPlatforms() == nil || baseResource.GetTechnologies() == nil || baseResource.GetIsAssigned() == nil || baseResource.GetSettingCount() == nil {
		resp.Diagnostics.AddError("Incomplete policy observation", "Required policy metadata was omitted; existing state was retained.")
		return
	}
	MapRemoteResourceStateToTerraform(ctx, &object, baseResource)

	settingsConfig := customrequest.GetRequestConfig{
		APIVersion:        customrequest.GraphAPIBeta,
		Endpoint:          r.ResourcePath,
		EndpointSuffix:    "/settings",
		ResourceIDPattern: "('id')",
		ResourceID:        object.ID.ValueString(),
		QueryParameters: map[string]string{
			"$expand": "children",
		},
	}

	var settingsResponse []byte

	settingsResponse, err = customrequest.GetConfigurationPolicyCollection(
		ctx,
		r.client.GetAdapter(),
		settingsConfig,
	)

	if err != nil {
		// Missing or invalid settings cannot prove that the parent policy is gone.
		resp.Diagnostics.AddError("Incomplete settings observation", err.Error())
		return
	}

	if err := sharedstater.StateConfigurationPolicySettingsStrict(ctx, &object, settingsResponse); err != nil {
		resp.Diagnostics.AddError("Invalid settings observation", err.Error())
		return
	}

	assignmentsConfig := settingsConfig
	assignmentsConfig.EndpointSuffix = "/assignments"
	assignmentsConfig.QueryParameters = nil
	assignmentsResponse, err := customrequest.GetConfigurationPolicyCollection(ctx, r.client.GetAdapter(), assignmentsConfig)
	if err != nil {
		resp.Diagnostics.AddError("Incomplete assignments observation", err.Error())
		return
	}
	if err := sharedstater.StateConfigurationPolicyAssignmentsStrict(ctx, &object, assignmentsResponse); err != nil {
		resp.Diagnostics.AddError("Invalid assignments observation", err.Error())
		return
	}
	var settingsEnvelope struct {
		Value []json.RawMessage `json:"value"`
	}
	if err := json.Unmarshal(settingsResponse, &settingsEnvelope); err != nil || int64(*baseResource.GetSettingCount()) != int64(len(settingsEnvelope.Value)) || *baseResource.GetIsAssigned() != (len(object.Assignments.Elements()) > 0) {
		resp.Diagnostics.AddError("Inconsistent policy observation", "Policy counts disagree with the complete settings or assignment collections; existing state was retained.")
		return
	}

	resp.Diagnostics.Append(resp.State.Set(ctx, &object)...)
	if resp.Diagnostics.HasError() {
		return
	}

	tflog.Debug(ctx, fmt.Sprintf("Finished Read Method: %s", ResourceName))
}

// Update handles the Update operation for Settings Catalog resources.
//
//   - Retrieves the planned changes from the update request
//   - Constructs the resource request body from the plan
//   - Sends PUT request to update the base resource and settings
//   - Constructs the assignment request body from the plan
//   - Sends POST request to update the assignments
//   - Retains prior observed state until complete readback succeeds
//   - Calls Read operation to fetch the latest state from the API with retry
//   - Updates the final state with the fresh data from the API
//
// The policy PUT and assignment POST are separate remote effects;
// and the final state reflects the actual state of the resource on the server.
func (r *SettingsCatalogJsonResource) Update(ctx context.Context, req resource.UpdateRequest, resp *resource.UpdateResponse) {
	var plan sharedmodels.SettingsCatalogJsonResourceModel
	var state sharedmodels.SettingsCatalogJsonResourceModel

	tflog.Debug(ctx, fmt.Sprintf("Starting Update of resource: %s", ResourceName))

	resp.Diagnostics.Append(req.Plan.Get(ctx, &plan)...)
	resp.Diagnostics.Append(req.State.Get(ctx, &state)...)
	if resp.Diagnostics.HasError() {
		return
	}

	ctx, cancel := crud.HandleTimeout(ctx, plan.Timeouts.Update, UpdateTimeout*time.Second, &resp.Diagnostics)
	if cancel == nil {
		return
	}
	defer cancel()

	requestBody, err := constructResource(ctx, &plan)
	if err != nil {
		resp.Diagnostics.AddError(
			"Error constructing resource for Update Method",
			fmt.Sprintf("Could not construct resource: %s: %s", ResourceName, err.Error()),
		)
		return
	}

	requestAssignment, err := constructAssignment(ctx, &plan)
	if err != nil {
		resp.Diagnostics.AddError(
			"Error constructing assignment for Create Method",
			fmt.Sprintf("Could not construct assignment: %s: %s", ResourceName, err.Error()),
		)
		return
	}

	putRequest := customrequest.PutRequestConfig{
		APIVersion:  customrequest.GraphAPIBeta,
		Endpoint:    r.ResourcePath,
		ResourceID:  state.ID.ValueString(),
		RequestBody: requestBody,
	}

	err = customrequest.PutRequestByResourceId(
		ctx,
		r.client.GetAdapter(),
		putRequest)

	if err != nil {
		errors.HandleKiotaGraphError(ctx, err, resp, constants.TfOperationUpdate, r.ReadPermissions)
		return
	}

	if requestAssignment != nil {
		_, err = r.client.
			DeviceManagement().
			ConfigurationPolicies().
			ByDeviceManagementConfigurationPolicyId(state.ID.ValueString()).
			Assign().
			Post(ctx, requestAssignment, nil)

	}

	if err != nil {
		errors.HandleKiotaGraphError(ctx, err, resp, constants.TfOperationUpdate, r.WritePermissions)
		return
	}

	readReq := resource.ReadRequest{State: resp.State, ProviderMeta: req.ProviderMeta}
	// Carry current management intent into readback without committing planned
	// values to response state. Strict Read still requires the complete observed
	// collection and replaces this marker with every observed target.
	assignmentIntent := types.SetNull(plan.Assignments.ElementType(ctx))
	if !plan.Assignments.IsNull() {
		assignmentIntent = types.SetValueMust(plan.Assignments.ElementType(ctx), nil)
	}
	resp.Diagnostics.Append(readReq.State.SetAttribute(ctx, path.Root("assignments"), assignmentIntent)...)
	if resp.Diagnostics.HasError() {
		return
	}
	stateContainer := &crud.UpdateResponseContainer{UpdateResponse: resp}

	opts := crud.DefaultReadWithRetryOptions()
	opts.Operation = constants.TfOperationUpdate
	opts.ResourceTypeName = ResourceName

	err = crud.ReadWithRetry(ctx, r.Read, readReq, stateContainer, opts)
	if err != nil {
		resp.Diagnostics.AddError(
			"Error reading resource state after update",
			fmt.Sprintf("Could not read resource state: %s: %s", ResourceName, err.Error()),
		)
		return
	}

	tflog.Debug(ctx, fmt.Sprintf("Finished updating %s with ID: %s", ResourceName, state.ID.ValueString()))
}

// Delete handles the Delete operation for Settings Catalog resources.
//
//   - Retrieves the current state from the delete request
//   - Validates the state data and timeout configuration
//   - Sends DELETE request to remove the resource from the API
//   - Cleans up by removing the resource from Terraform state
//
// All assignments and settings associated with the resource are automatically removed as part of the deletion.
func (r *SettingsCatalogJsonResource) Delete(ctx context.Context, req resource.DeleteRequest, resp *resource.DeleteResponse) {
	var object sharedmodels.SettingsCatalogJsonResourceModel

	tflog.Debug(ctx, fmt.Sprintf("Starting deletion of resource: %s", ResourceName))

	resp.Diagnostics.Append(req.State.Get(ctx, &object)...)
	if resp.Diagnostics.HasError() {
		return
	}

	ctx, cancel := crud.HandleTimeout(ctx, object.Timeouts.Delete, DeleteTimeout*time.Second, &resp.Diagnostics)
	if cancel == nil {
		return
	}
	defer cancel()

	err := r.client.
		DeviceManagement().
		ConfigurationPolicies().
		ByDeviceManagementConfigurationPolicyId(object.ID.ValueString()).
		Delete(ctx, nil)

	if err != nil {
		errors.HandleKiotaGraphError(ctx, err, resp, constants.TfOperationDelete, r.WritePermissions)
		return
	}

	tflog.Debug(ctx, fmt.Sprintf("Removing %s from Terraform state", ResourceName))

	resp.State.RemoveResource(ctx)

	tflog.Debug(ctx, fmt.Sprintf("Finished Delete Method: %s", ResourceName))
}
